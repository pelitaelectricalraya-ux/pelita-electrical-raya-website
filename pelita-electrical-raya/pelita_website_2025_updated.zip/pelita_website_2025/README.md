
Pelita Electrical Raya - Self-hosted website (2025)
===================================================

Isi paket:
- index.html, style.css, script.js
- assets/per2025.png (logo)
- server.js (Node.js simple server: static site + upload + contact endpoints + proxy example)
- package.json (dependencies)
- uploads/ (created at runtime) and contacts.json (created at runtime)
- README (this file)

Menjalankan (di mesin lokal):
1. Pastikan Node.js (v14+) dan npm terpasang.
2. Buka terminal pada folder proyek:
   npm install
   npm start
3. Buka browser: http://localhost:3000

Tentang "tanpa bayar sewa":
- Paket ini memungkinkan Anda menjalankan situs sepenuhnya di mesin sendiri (laptop/PC/server lokal).
- Untuk menjangkau publik tanpa biaya hosting, Anda bisa menggunakan jaringan lokal (LAN) atau mengatur PC sebagai server. Untuk akses global diperlukan domain & hosting publik (biasanya berbayar).
- Paket ini juga berisi contoh implementasi proxy (http-proxy-middleware) dan endpoint upload/contact untuk kebutuhan internal.

DNS / Domain / Email / Proxy (catatan implementasi)
---------------------------------------------------
- Implementasi DNS dan mail server sepenuhnya memerlukan konfigurasi jaringan dan port-forwarding pada router, serta akses ke DNS publik jika ingin domain global.
- Paket ini berisi skrip dan konfigurasi dasar untuk pengembangan lokal. Jika Anda ingin benar-benar membuat DNS server dan mail server:
  - DNS: gunakan BIND9 atau knot-dns di Linux; untuk development gunakan dnsmasq.
  - Mail: gunakan Postfix + Dovecot atau solusi sederhana berbasis Haraka/smtp-server (Node.js) untuk lingkungan dev.
  - Proxy: contoh di server.js menggunakan http-proxy-middleware.
- Kami menyertakan kontak email contoh:
  - pelitaelectricalraya@gmail.com
  - support@pelitaelectricalraya.com
  - maintenance@pelitaelectricalraya.com
  - info@pelitaelectricalraya.com

Ekspor & ZIP:
Semua file sudah dikemas dalam ZIP siap unduh.

Lisensi & Catatan:
- Silakan periksa kembali kontak dan isi sebelum publikasi.
- Untuk produksi (akses publik, email nyata, DNS global) disarankan menggunakan layanan hosting & domain berbayar atau VPS agar aman & terpercaya.



Advanced appendix: local DNS, Nginx deploy, and Haraka SMTP
----------------------------------------------------------
- DNS: Use dnsmasq to map pelita.local (or custom name) to your server's LAN IP. After creating the config, restart dnsmasq.
- Nginx: Place nginx_pelita_example.conf in /etc/nginx/sites-available/ and symlink to sites-enabled. Ensure root matches extracted site folder.
- SSL: Use certbot with Let's Encrypt if you have a public domain. For local testing, use self-signed certs.
- SMTP: Haraka can be used for development. For production email, use Postfix + Dovecot or a trusted mail provider.

