// script.js - basic interactivity & upload simulation
document.addEventListener('DOMContentLoaded', ()=> {
  const drop = document.getElementById('dropzone');
  const contactForm = document.getElementById('contactForm');

  // Drag & Drop
  ['dragenter','dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.style.opacity=0.8 }));
  ['dragleave','drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.style.opacity=1 }));
  drop.addEventListener('drop', async (e) => {
    const files = Array.from(e.dataTransfer.files || []);
    await uploadFiles(files);
  });
  drop.addEventListener('click', ()=> {
    const inp = document.createElement('input');
    inp.type='file'; inp.multiple=true;
    inp.onchange = () => uploadFiles(Array.from(inp.files));
    inp.click();
  });

  async function uploadFiles(files){
    if(!files.length) return alert('Tidak ada file.');
    // simulate upload to local server endpoint /upload
    const form = new FormData();
    files.forEach(f=>form.append('files', f));
    try{
      const res = await fetch('/upload', {method:'POST', body:form});
      if(res.ok) alert('File dikirim ke server lokal (simulasi).');
      else alert('Gagal mengirim file (simulasi).');
    }catch(err){
      alert('Server lokal tidak aktif. Jalankan "npm start" pada folder proyek.');
    }
  }

  contactForm.addEventListener('submit', async (ev)=> {
    ev.preventDefault();
    const data = new FormData(contactForm);
    try{
      const res = await fetch('/contact', {method:'POST', body: data});
      if(res.ok) alert('Pesan terkirim. Terima kasih!');
      else alert('Gagal mengirim pesan.');
    }catch(e){
      alert('Server lokal tidak aktif. Jalankan "npm start" pada folder proyek.');
    }
  });
});
