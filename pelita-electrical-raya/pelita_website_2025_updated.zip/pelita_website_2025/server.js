// server.js - simple local server for static site, upload simulation, simple proxy, and basic SMTP usage notes
const express = require('express');
const multer = require('multer');
const path = require('path');
const { createProxyMiddleware } = require('http-proxy-middleware');
const fs = require('fs');

const app = express();
const upload = multer({ dest: path.join(__dirname, 'uploads/') });

app.use(express.static(path.join(__dirname)));

// simple upload endpoint
app.post('/upload', upload.array('files'), (req, res) => {
  // files saved to uploads/ - treat as simulation for drag&drop
  res.status(200).send('uploaded');
});

// simple contact endpoint - would normally send email via SMTP
app.post('/contact', express.urlencoded({ extended: true }), (req, res) => {
  // store contact to local JSON (simulated)
  const data = { time: new Date().toISOString(), ...req.body };
  const dbFile = path.join(__dirname, 'contacts.json');
  let arr = [];
  if(fs.existsSync(dbFile)) arr = JSON.parse(fs.readFileSync(dbFile));
  arr.push(data);
  fs.writeFileSync(dbFile, JSON.stringify(arr, null, 2));
  res.status(200).send('ok');
});

// example proxy route (local)
app.use('/proxy', createProxyMiddleware({
  target: 'http://example.com',
  changeOrigin: true,
  pathRewrite: {'^/proxy' : '/'},
}));

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log(`Pelita local site running at http://localhost:${port}`));
