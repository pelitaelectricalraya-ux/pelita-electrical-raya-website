
Pelita Electrical Raya - Website package (2025)
-----------------------------------------------

Konten ini termasuk file siap pakai untuk di-upload ke GitHub Pages / Netlify.
Folder: pelitaelectricalraya_website

Files:
- index.html
- assets/css/style.css
- assets/js/script.js
- assets/images/per2025.png  (logo yang Anda berikan)

EMAILS to create (suggested, not auto-created):
- pelitaelectricalraya@gmail.com  (existing)
- support@pelitaelectricalraya.com
- maintenance@pelitaelectricalraya.com
- info@pelitaelectricalraya.com

SHORT DEPLOY GUIDE:
1. Upload folder contents to a GitHub repo and enable GitHub Pages (branch: main, folder: / (root)).
2. Or sign up at Netlify and drag-drop the folder to publish instantly.
3. For custom domain (free): register a Freenom domain (example: pelitaelectricalraya.tk) and point it to Netlify/GitHub Pages via DNS.
4. Use Cloudflare to proxy traffic (enable SSL) and manage DNS records.
5. Use Zoho Mail (free tier) to host your custom domain email. Follow Zoho's settings to add MX and TXT records via Cloudflare.

HOW TO SEND THIS ZIP FILE TO pelitaelectricalraya@gmail.com
- I cannot send emails on your behalf. To email the file:
  1. Download the zip from the link provided in this message.
  2. Compose a new Gmail message to pelitaelectricalraya@gmail.com and attach the zip.
  3. Or use command-line: 
     - Linux/Mac:  `echo "See attachment" | mutt -s "Website files" -a pelitaelectricalraya_website.zip -- pelitaelectricalraya@gmail.com`
     - Windows: attach in Outlook or webmail client.

If you want, I can also provide:
- A step-by-step script of exact DNS records and verification steps for Zoho Mail + Cloudflare.
- A ready Git repo structure (I already made the folder).

Thank you!
