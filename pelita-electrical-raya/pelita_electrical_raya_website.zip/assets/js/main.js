
// Simple interactivity placeholder
document.addEventListener('DOMContentLoaded', function(){
  // Future: add animations or contact form handlers
});
