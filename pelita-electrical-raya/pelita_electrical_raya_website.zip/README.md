
Pelita Electrical Raya - Website Package (2025)
===============================================

Isi Paket:
- index.html, about.html, services.html, portfolio.html, contact.html
- assets/css/styles.css
- assets/js/main.js
- assets/img/per2025.png  (logo)
- configs/ (contoh konfigurasi nginx, bind9, mailserver)
- README (panduan deploy cepat)
- ZIP file siap publish

Kontak Utama:
- Telepon/WhatsApp/SMS/Layanan 24 Jam/Pengaduan: +62 813 8069 0076
- Email publik: pelitaelectricalraya@gmail.com
- Support: support@pelitaelectricalraya.tk
- Maintenance: maintenance@pelitaelectricalraya.tk
- Layanan: info@pelitaelectricalraya.tk

Panduan Singkat Deploy Lokal (tanpa beli domain):
1. Jalankan website statis di server lokal atau hosting yang mendukung (GitHub Pages, Netlify, atau VPS).
2. Untuk domain lokal gunakan hostnames seperti pelitaelectricalraya.local atau subdomain dari domain .tk gratis.
   - Jika menggunakan .local: tambahkan ke /etc/hosts -> 127.0.0.1 pelitaelectricalraya.local
   - Jika ingin domain publik gratis: coba Freenom (.tk) dan arahkan ke IP VPS Anda.

DNS & Email (contoh):
- Contoh file zone DNS (configs/dns_zone.example) disertakan.
- Untuk email mandiri: gunakan iRedMail atau Mailcow pada VPS (contoh configs/mailcow.example).
- Jika tidak ingin mengelola email sendiri, Anda bisa gunakan Gmail (pelitaelectricalraya@gmail.com) untuk komunikasi awal.

Proxy & SSL:
- configs/nginx.example menunjukkan reverse proxy untuk aplikasimu.
- Caddyfile example disertakan untuk TLS otomatis (jika menggunakan domain publik yang valid).

Keamanan & Saran:
- Lindungi admin panel, gunakan rate limiting.
- Backup konfigurasi DNS & mailserver.
- Gunakan firewall & monitoring.

Lisensi:
- File ini dibuat khusus untuk Pelita Electrical Raya. Silakan sesuaikan isi, foto, dan alamat sesuai kebutuhan.

