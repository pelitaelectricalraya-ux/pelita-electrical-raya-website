Pelita Electrical Raya 2025 Infrastructure - Ultimate Edition

This is a full-stack deployment for a professional electrical services company. Includes:
- Website (HTML, CSS, JS, assets)
- Backend API (Node.js, Express, SQLite)
- Admin Panel (Basic Auth)
- Docker Compose
- Mail server (Mailcow)
- DNS setup (Bind9)
- SSL (Caddy)
- Automated backup system (rclone + Mega.nz)

Please read the instructions in DEPLOYMENT_PLAYBOOK.md for full setup steps.