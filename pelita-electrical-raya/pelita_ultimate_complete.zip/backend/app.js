
require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');
const sqlite3 = require('sqlite3').verbose();
const basicAuth = require('basic-auth');

const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static('public'));

// Initialize SQLite database
const db = new sqlite3.Database('./data/submissions.db');
db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS submissions (id INTEGER PRIMARY KEY, name TEXT, email TEXT, phone TEXT, subject TEXT, message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
});

// Contact form endpoint
app.post('/api/contact', (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  if (!email || !message) return res.status(400).json({error: 'Email dan pesan wajib'});  
  db.run(`INSERT INTO submissions (name, email, phone, subject, message) VALUES (?,?,?,?,?)`, [name, email, phone, subject, message], (err) => {
    if (err) return res.status(500).json({error: 'Error menyimpan data'});
    const transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
    const mailOptions = { from: process.env.SMTP_USER, to: process.env.CONTACT_RECIPIENT, subject: subject || 'Pesan Kontak', text: `Dari: ${name}
Email: ${email}

${message}` };
    transporter.sendMail(mailOptions, (err, info) => {
      if (err) return res.json({ok: true, warning: 'Gagal kirim email'});
      res.json({ok: true});
    });
  });
});

// Basic Auth Admin
function auth(req, res, next) {
  const user = basicAuth(req);
  if (!user || user.name !== process.env.ADMIN_USER || user.pass !== process.env.ADMIN_PASS) {
    res.set('WWW-Authenticate', 'Basic realm="Admin"');
    return res.status(401).send('Authentikasi diperlukan');
  }
  next();
}

app.get('/admin', auth, (req, res) => {
  res.sendFile('admin.html', { root: __dirname });
});

// Admin panel for data submissions
app.get('/admin/submissions', auth, (req, res) => {
  db.all('SELECT * FROM submissions ORDER BY created_at DESC LIMIT 100', (err, rows) => {
    if (err) return res.status(500).send('Error database');
    res.json(rows);
  });
});

app.listen(5000, () => console.log('Server berjalan pada http://localhost:5000'));
