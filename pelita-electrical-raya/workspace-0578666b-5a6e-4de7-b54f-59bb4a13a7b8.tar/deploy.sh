#!/bin/bash

# Deploy Script for Pelita Electrical Raya Website
# This script deploys the website to GitHub Pages

echo "🚀 Starting deployment process for Pelita Electrical Raya Website..."

# Check if we're on the main branch
CURRENT_BRANCH=$(git branch --show-current)
if [ "$CURRENT_BRANCH" != "main" ]; then
    echo "⚠️  Warning: You're not on the main branch. Current branch: $CURRENT_BRANCH"
    read -p "Do you want to continue? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "❌ Deployment cancelled."
        exit 1
    fi
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build the project
echo "🔨 Building the project..."
npm run build

# Check if build was successful
if [ $? -ne 0 ]; then
    echo "❌ Build failed. Please fix the errors and try again."
    exit 1
fi

# Create .nojekyll file to bypass Jekyll processing
echo "📄 Creating .nojekyll file..."
touch out/.nojekyll

# Add the out directory to git
echo "📁 Adding build files to git..."
git add out/

# Commit the changes
echo "💾 Committing changes..."
git commit -m "Deploy to GitHub Pages - $(date)"

# Push to gh-pages branch
echo "🚀 Pushing to GitHub Pages..."
git subtree push --prefix out origin gh-pages

if [ $? -eq 0 ]; then
    echo "✅ Deployment successful!"
    echo "🌐 Your website is now live at: https://pelitaelectricalraya.github.io/pelita-electrical-rayawebsite/"
    echo ""
    echo "📋 Next steps:"
    echo "1. Setup your custom domain with Freenom (.tk, .ml, .ga, .cf, .gq)"
    echo "2. Configure Cloudflare for DNS and proxy"
    echo "3. Setup ImprovMX for professional email forwarding"
    echo ""
    echo "📞 For support: +62 813 8069 0076"
else
    echo "❌ Deployment failed. Please check the error messages above."
    exit 1
fi