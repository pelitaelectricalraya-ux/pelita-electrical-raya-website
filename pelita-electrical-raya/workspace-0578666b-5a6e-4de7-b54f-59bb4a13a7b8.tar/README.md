# Pelita Electrical Raya - Website Portofolio

Website portofolio profesional untuk Pelita Electrical Raya - Perusahaan jasa instalasi dan maintenance listrik terpercaya di Jakarta.

## 🌟 Fitur Website

- ✅ **Desain Elegan & Profesional** - Tampilan modern dengan warna perusahaan (biru, kuning, merah)
- ✅ **Fully Responsive** - Tampilan sempurna di desktop, tablet, dan mobile
- ✅ **SEO Optimized** - Meta tags lengkap untuk mesin pencari
- ✅ **Interaktif & Animasi** - Efek scroll yang halus dan animasi menarik
- ✅ **WhatsApp Integration** - Tombol WhatsApp langsung dan floating button
- ✅ **Contact Form** - Formulir kontak yang user-friendly
- ✅ **Portfolio Gallery** - Galeri proyek-proyek perusahaan
- ✅ **Service Showcase** - Layanan lengkap dengan detail fitur

## 📞 Informasi Kontak

- **Alamat**: Jalan Masjid Nurul Huda 33 RT.1/RW.1 Cengkareng Timur, Cengkareng, Jakarta Barat, DKI Jakarta 11730A
- **Telepon/WhatsApp**: +62 813 8069 0076
- **Email**: pelitaelectricalraya@gmail.com
- **Layanan**: 24 Jam

## 🚀 Cara Deploy Website Gratis Selamanya

### 1. GitHub Pages (Hosting Gratis)

```bash
# 1. Fork atau clone repository ini
git clone [repository-url]
cd pelita-electrical-raya

# 2. Install dependencies
npm install

# 3. Build untuk production
npm run build

# 4. Deploy ke GitHub Pages
npm run deploy
```

### 2. Domain Gratis (Freenom)

1. Kunjungi [Freenom](https://www.freenom.com/)
2. Cari domain gratis (.tk, .ml, .ga, .cf, .gq)
3. Pilih domain yang tersedia (misal: `pelitaelectricalraya.tk`)
4. Registrasi dengan email Anda
5. Set DNS records:
   ```
   Type: CNAME
   Name: @
   Target: [username].github.io
   TTL: 3600
   ```

### 3. Cloudflare (DNS & Proxy Gratis)

1. Daftar di [Cloudflare](https://www.cloudflare.com/)
2. Tambahkan domain Anda
3. Update nameserver sesuai instruksi Cloudflare
4. Aktifkan proxy (orange cloud)
5. Setup SSL certificate (gratis otomatis)

### 4. Email Profesional Gratis (ImprovMX)

1. Kunjungi [ImprovMX](https://improvmx.com/)
2. Tambahkan domain Anda
3. Buat email forwarding:
   - Dari: `info@pelitaelectricalraya.tk`
   - Ke: `pelitaelectricalraya@gmail.com`
4. Update MX records di Cloudflare

## 🛠️ Teknologi yang Digunakan

- **Next.js 15** - React framework dengan App Router
- **TypeScript** - Type safety dan better development experience
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Modern UI components
- **Lucide Icons** - Beautiful icon library
- **Sonner** - Toast notifications

## 📁 Struktur File

```
src/
├── app/
│   ├── layout.tsx          # Root layout dengan metadata
│   ├── page.tsx           # Halaman utama
│   └── globals.css        # Global styles
├── components/
│   ├── ui/                # shadcn/ui components
│   └── PelitaElectricalWebsite.tsx  # Main website component
└── lib/
    └── db.ts              # Database utilities
```

## 🎨 Kustomisasi

### Mengubah Warna Tema
Edit file `src/app/globals.css` dan ubah CSS variables:

```css
:root {
  --primary: #002B5B;      /* Biru tua */
  --secondary: #FFD700;    /* Kuning emas */
  --accent: #E63946;       /* Merah aksen */
}
```

### Mengubah Informasi Kontak
Edit file `src/components/PelitaElectricalWebsite.tsx` dan update:

```typescript
const contactInfo = {
  phone: "+62 813 8069 0076",
  email: "pelitaelectricalraya@gmail.com",
  address: "Jalan Masjid Nurul Huda 33 RT.1/RW.1 Cengkareng Timur..."
}
```

### Menambah Portfolio Items
Edit array `portfolioItems` di component utama:

```typescript
const portfolioItems = [
  {
    title: "Nama Proyek",
    category: "Residential/Commercial/Industrial",
    description: "Deskripsi proyek...",
    image: "/path/to/image.jpg"
  }
]
```

## 🔧 Development Commands

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Run linter
npm run lint
```

## 📱 Mobile Optimization

Website sudah dioptimalkan untuk mobile dengan:
- Responsive navigation menu
- Touch-friendly buttons
- Optimized images
- Fast loading times
- Proper viewport settings

## 🌐 SEO Features

- Meta tags lengkap
- Open Graph tags
- Twitter Card tags
- Semantic HTML5 structure
- Proper heading hierarchy
- Alt text untuk images
- Fast loading optimization

## 📈 Performance

- Next.js optimization
- Image optimization
- Code splitting
- Lazy loading
- Minimal bundle size
- Fast API responses

## 🔒 Security

- HTTPS dengan Cloudflare SSL
- Input sanitization
- XSS protection
- Secure headers
- No sensitive data exposure

## 📞 Support

Jika butuh bantuan atau ada pertanyaan:
- WhatsApp: +62 813 8069 0076
- Email: pelitaelectricalraya@gmail.com

## 📄 License

Website ini dikembangkan untuk Pelita Electrical Raya. Seluruh hak dilindungi.

---

**© 2025 Pelita Electrical Raya. Website ini dibuat dan dikelola sendiri oleh Pelita Electrical Raya.**