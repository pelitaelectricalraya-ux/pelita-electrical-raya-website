import PelitaElectricalWebsite from '@/components/PelitaElectricalWebsite'

export default function Home() {
  return <PelitaElectricalWebsite />
}