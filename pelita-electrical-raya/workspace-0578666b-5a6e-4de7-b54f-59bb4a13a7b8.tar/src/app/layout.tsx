import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Pelita Electrical Raya - Solusi Listrik Profesional",
  description: "Pelita Electrical Raya - Solusi instalasi, maintenance, dan pengadaan material listrik untuk rumah & industri. Aman, cepat, dan bergaransi. Layanan 24 jam.",
  keywords: ["Pelita Electrical Raya", "listrik", "instalasi listrik", "maintenance listrik", "electrical services", "Jakarta", "Cengkareng"],
  authors: [{ name: "Pelita Electrical Raya" }],
  openGraph: {
    title: "Pelita Electrical Raya - Solusi Listrik Profesional",
    description: "Instalasi, maintenance, dan pengadaan material listrik untuk rumah & industri. Layanan 24 jam.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Pelita Electrical Raya - Solusi Listrik Profesional",
    description: "Instalasi, maintenance, dan pengadaan material listrik untuk rumah & industri. Layanan 24 jam.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <SonnerToaster />
      </body>
    </html>
  );
}
