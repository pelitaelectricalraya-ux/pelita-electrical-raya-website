import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { broadcastMeritUpdate } from '@/lib/socket'

// Get the Socket.IO server instance
const getSocketServer = () => {
  const globalSocket = global as any
  return globalSocket.io
}

export async function GET() {
  try {
    let meritBox = await db.meritBox.findFirst()
    
    if (!meritBox) {
      meritBox = await db.meritBox.create({
        data: {
          totalMerit: 0
        }
      })
    }

    return NextResponse.json({
      id: meritBox.id,
      totalMerit: meritBox.totalMerit
    })
  } catch (error) {
    console.error('Failed to fetch merit data:', error)
    return NextResponse.json(
      { error: 'Failed to fetch merit data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { amount = 1 } = await request.json()
    
    if (amount <= 0) {
      return NextResponse.json(
        { error: 'Amount must be positive' },
        { status: 400 }
      )
    }

    let meritBox = await db.meritBox.findFirst()
    
    if (!meritBox) {
      meritBox = await db.meritBox.create({
        data: {
          totalMerit: amount
        }
      })
    } else {
      meritBox = await db.meritBox.update({
        where: { id: meritBox.id },
        data: {
          totalMerit: meritBox.totalMerit + amount
        }
      })
    }

    // Log the merit addition
    await db.meritLog.create({
      data: {
        amount,
        ipAddress: request.ip || request.headers.get('x-forwarded-for') || 'unknown',
        userAgent: request.headers.get('user-agent') || 'unknown'
      }
    })

    // Broadcast real-time update
    const io = getSocketServer()
    if (io) {
      broadcastMeritUpdate(io, meritBox.totalMerit)
    }

    return NextResponse.json({
      id: meritBox.id,
      totalMerit: meritBox.totalMerit
    })
  } catch (error) {
    console.error('Failed to add merit:', error)
    return NextResponse.json(
      { error: 'Failed to add merit' },
      { status: 500 }
    )
  }
}