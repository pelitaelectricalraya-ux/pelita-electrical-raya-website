import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { broadcastMeritUpdate } from '@/lib/socket'

// Get the Socket.IO server instance
const getSocketServer = () => {
  const globalSocket = global as any
  return globalSocket.io
}

export async function POST(request: NextRequest) {
  try {
    const { amount, reason } = await request.json()
    
    if (!amount || amount === 0) {
      return NextResponse.json(
        { error: 'Adjustment amount cannot be zero' },
        { status: 400 }
      )
    }

    let meritBox = await db.meritBox.findFirst()
    
    if (!meritBox) {
      meritBox = await db.meritBox.create({
        data: {
          totalMerit: Math.max(0, amount)
        }
      })
    } else {
      const newTotal = Math.max(0, meritBox.totalMerit + amount)
      meritBox = await db.meritBox.update({
        where: { id: meritBox.id },
        data: {
          totalMerit: newTotal
        }
      })

      // Log the adjustment
      await db.meritLog.create({
        data: {
          amount,
          reason: reason || `Admin adjustment: ${amount > 0 ? '+' : ''}${amount}`,
          ipAddress: request.ip || request.headers.get('x-forwarded-for') || 'admin',
          userAgent: request.headers.get('user-agent') || 'admin panel'
        }
      })
    }

    // Broadcast real-time update
    const io = getSocketServer()
    if (io) {
      broadcastMeritUpdate(io, meritBox.totalMerit)
    }

    return NextResponse.json({
      id: meritBox.id,
      totalMerit: meritBox.totalMerit
    })
  } catch (error) {
    console.error('Failed to adjust merit:', error)
    return NextResponse.json(
      { error: 'Failed to adjust merit' },
      { status: 500 }
    )
  }
}