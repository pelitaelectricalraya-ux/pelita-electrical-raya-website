import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const logs = await db.meritLog.findMany({
      orderBy: {
        timestamp: 'desc'
      },
      take: 100 // Limit to last 100 entries
    })

    return NextResponse.json({
      logs: logs.map(log => ({
        id: log.id,
        amount: log.amount,
        reason: log.reason,
        timestamp: log.timestamp.toISOString(),
        ipAddress: log.ipAddress,
        userAgent: log.userAgent
      }))
    })
  } catch (error) {
    console.error('Failed to fetch merit logs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch merit logs' },
      { status: 500 }
    )
  }
}