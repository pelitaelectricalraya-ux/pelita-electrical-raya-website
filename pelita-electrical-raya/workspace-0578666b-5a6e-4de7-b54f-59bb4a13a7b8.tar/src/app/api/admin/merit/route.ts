import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { broadcastMeritUpdate } from '@/lib/socket'

// Get the Socket.IO server instance
const getSocketServer = () => {
  const globalSocket = global as any
  return globalSocket.io
}

export async function PUT(request: NextRequest) {
  try {
    const { totalMerit, reason } = await request.json()
    
    if (totalMerit < 0) {
      return NextResponse.json(
        { error: 'Total merit cannot be negative' },
        { status: 400 }
      )
    }

    let meritBox = await db.meritBox.findFirst()
    
    if (!meritBox) {
      meritBox = await db.meritBox.create({
        data: {
          totalMerit
        }
      })
    } else {
      const oldMerit = meritBox.totalMerit
      meritBox = await db.meritBox.update({
        where: { id: meritBox.id },
        data: {
          totalMerit
        }
      })

      // Log the admin update
      await db.meritLog.create({
        data: {
          amount: totalMerit - oldMerit,
          reason: reason || 'Admin manual update',
          ipAddress: request.ip || request.headers.get('x-forwarded-for') || 'admin',
          userAgent: request.headers.get('user-agent') || 'admin panel'
        }
      })
    }

    // Broadcast real-time update
    const io = getSocketServer()
    if (io) {
      broadcastMeritUpdate(io, meritBox.totalMerit)
    }

    return NextResponse.json({
      id: meritBox.id,
      totalMerit: meritBox.totalMerit
    })
  } catch (error) {
    console.error('Failed to update merit:', error)
    return NextResponse.json(
      { error: 'Failed to update merit' },
      { status: 500 }
    )
  }
}