'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Settings, 
  Save, 
  RefreshCw, 
  Plus, 
  Minus, 
  History,
  AlertTriangle,
  CheckCircle
} from 'lucide-react'
import { toast } from 'sonner'

interface MeritData {
  totalMerit: number
  id: string
}

interface MeritLogEntry {
  id: string
  amount: number
  reason: string | null
  timestamp: string
  ipAddress: string | null
  userAgent: string | null
}

export default function AdminPage() {
  const [meritData, setMeritData] = useState<MeritData | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [newMeritValue, setNewMeritValue] = useState('')
  const [adjustmentAmount, setAdjustmentAmount] = useState('')
  const [adjustmentReason, setAdjustmentReason] = useState('')
  const [meritLogs, setMeritLogs] = useState<MeritLogEntry[]>([])
  const [isLoadingLogs, setIsLoadingLogs] = useState(false)

  const fetchMeritData = async () => {
    try {
      const response = await fetch('/api/merit')
      if (response.ok) {
        const data = await response.json()
        setMeritData(data)
        setNewMeritValue(data.totalMerit.toString())
      }
    } catch (error) {
      console.error('Failed to fetch merit data:', error)
    }
  }

  const fetchMeritLogs = async () => {
    setIsLoadingLogs(true)
    try {
      const response = await fetch('/api/admin/merit/logs')
      if (response.ok) {
        const data = await response.json()
        setMeritLogs(data.logs || [])
      }
    } catch (error) {
      console.error('Failed to fetch merit logs:', error)
    } finally {
      setIsLoadingLogs(false)
    }
  }

  const updateMeritValue = async () => {
    if (!meritData || !newMeritValue) return
    
    const newValue = parseInt(newMeritValue)
    if (isNaN(newValue) || newValue < 0) {
      toast.error('Please enter a valid positive number')
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch('/api/admin/merit', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          totalMerit: newValue,
          reason: 'Manual admin update'
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setMeritData(data)
        toast.success('Merit value updated successfully! 🎉')
        fetchMeritLogs()
      } else {
        toast.error('Failed to update merit value')
      }
    } catch (error) {
      console.error('Failed to update merit value:', error)
      toast.error('Failed to update merit value')
    } finally {
      setIsLoading(false)
    }
  }

  const adjustMerit = async (adjustment: number) => {
    if (!meritData) return
    
    setIsLoading(true)
    try {
      const response = await fetch('/api/admin/merit/adjust', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          amount: adjustment,
          reason: adjustmentReason || `Admin adjustment: ${adjustment > 0 ? '+' : ''}${adjustment}`
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setMeritData(data)
        setNewMeritValue(data.totalMerit.toString())
        setAdjustmentAmount('')
        setAdjustmentReason('')
        toast.success(`Merit ${adjustment > 0 ? 'added' : 'removed'} successfully! 🎉`)
        fetchMeritLogs()
      } else {
        toast.error('Failed to adjust merit')
      }
    } catch (error) {
      console.error('Failed to adjust merit:', error)
      toast.error('Failed to adjust merit')
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchMeritData()
    fetchMeritLogs()
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
          <div className="flex items-center gap-3 mb-2">
            <Settings className="w-8 h-8 text-orange-500" />
            <h1 className="text-3xl font-bold text-gray-800">Merit Box Admin</h1>
          </div>
          <p className="text-gray-600">Manage and monitor the shared merit system</p>
        </div>

        <Tabs defaultValue="manage" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="manage">Manage Merit</TabsTrigger>
            <TabsTrigger value="logs">Activity Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="manage" className="space-y-6">
            {/* Current Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  Current Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                {meritData ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-medium">Total Merit Points:</span>
                      <Badge variant="secondary" className="text-xl px-4 py-2">
                        {meritData.totalMerit.toLocaleString()}
                      </Badge>
                    </div>
                    <Button 
                      onClick={fetchMeritData}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Refresh
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-500 mx-auto"></div>
                    <p className="text-gray-500 mt-2">Loading...</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Manual Update */}
            <Card>
              <CardHeader>
                <CardTitle>Manual Update</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="merit-value">Set Total Merit Value</Label>
                  <Input
                    id="merit-value"
                    type="number"
                    value={newMeritValue}
                    onChange={(e) => setNewMeritValue(e.target.value)}
                    placeholder="Enter merit value"
                    min="0"
                  />
                </div>
                <Button 
                  onClick={updateMeritValue}
                  disabled={isLoading || !meritData}
                  className="w-full"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {isLoading ? 'Updating...' : 'Update Value'}
                </Button>
              </CardContent>
            </Card>

            {/* Quick Adjustments */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Adjustments</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="adjustment-amount">Adjustment Amount</Label>
                  <Input
                    id="adjustment-amount"
                    type="number"
                    value={adjustmentAmount}
                    onChange={(e) => setAdjustmentAmount(e.target.value)}
                    placeholder="Enter amount (can be negative)"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="adjustment-reason">Reason (Optional)</Label>
                  <Input
                    id="adjustment-reason"
                    value={adjustmentReason}
                    onChange={(e) => setAdjustmentReason(e.target.value)}
                    placeholder="Reason for adjustment"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    onClick={() => adjustMerit(Math.abs(parseInt(adjustmentAmount) || 0))}
                    disabled={isLoading || !meritData || !adjustmentAmount}
                    variant="default"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add
                  </Button>
                  <Button 
                    onClick={() => adjustMerit(-Math.abs(parseInt(adjustmentAmount) || 0))}
                    disabled={isLoading || !meritData || !adjustmentAmount}
                    variant="destructive"
                  >
                    <Minus className="w-4 h-4 mr-2" />
                    Remove
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5 text-blue-500" />
                  Activity Logs
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingLogs ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-500 mx-auto"></div>
                    <p className="text-gray-500 mt-2">Loading logs...</p>
                  </div>
                ) : meritLogs.length > 0 ? (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {meritLogs.map((log) => (
                      <div key={log.id} className="border rounded-lg p-3 bg-gray-50">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant={log.amount > 0 ? "default" : "destructive"}>
                              {log.amount > 0 ? '+' : ''}{log.amount}
                            </Badge>
                            <span className="text-sm text-gray-600">
                              {new Date(log.timestamp).toLocaleString()}
                            </span>
                          </div>
                        </div>
                        {log.reason && (
                          <p className="text-sm text-gray-700 mt-1">{log.reason}</p>
                        )}
                        <p className="text-xs text-gray-500 mt-1">
                          IP: {log.ipAddress || 'Unknown'}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertTriangle className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-500">No activity logs found</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}