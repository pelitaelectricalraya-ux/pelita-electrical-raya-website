'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Phone, 
  MessageCircle, 
  Mail, 
  MapPin, 
  Clock, 
  Zap,
  Shield,
  Users,
  Award,
  ChevronRight,
  Menu,
  X,
  ArrowRight,
  CheckCircle,
  Lightbulb,
  Wrench,
  Home,
  AlertCircle
} from 'lucide-react'
import { toast } from 'sonner'

export default function PelitaElectricalWebsite() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('home')

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
      setActiveSection(sectionId)
      setIsMobileMenuOpen(false)
    }
  }

  const handleWhatsAppClick = () => {
    window.open('https://wa.me/6281380690076', '_blank')
  }

  const handleCallClick = () => {
    window.open('tel:+6281380690076')
  }

  const handleEmailClick = () => {
    window.open('mailto:pelitaelectricalraya@gmail.com')
  }

  const services = [
    {
      icon: <Home className="w-8 h-8" />,
      title: "Instalasi Listrik Rumah & Gedung",
      description: "Pemasangan instalasi listrik baru untuk rumah, kantor, dan gedung komersial dengan standar keamanan tinggi.",
      features: ["Instalasi Baru", "Peningkatan Kapasitas", "Grounding System"]
    },
    {
      icon: <Wrench className="w-8 h-8" />,
      title: "Maintenance & Perbaikan",
      description: "Perawatan berkala dan perbaikan kerusakan listrik untuk mencegah masalah serius di kemudian hari.",
      features: ["Inspeksi Berkala", "Perbaikan Darurat", "Preventive Maintenance"]
    },
    {
      icon: <Lightbulb className="w-8 h-8" />,
      title: "Pengadaan Material Listrik",
      description: "Supplier resmi berbagai material listrik berkualitas dengan garansi keaslian produk.",
      features: ["Kabel Berkualitas", "Panel Listrik", "Aksesoris Lengkap"]
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Layanan Darurat 24 Jam",
      description: "Siaga 24 jam untuk keadaan darurat kelistrikan di rumah atau tempat usaha Anda.",
      features: ["Respon Cepat", "Tim Ahli", "Peralatan Lengkap"]
    }
  ]

  const portfolioItems = [
    {
      title: "Instalasi Listrik Rumah Tinggal",
      category: "Residential",
      description: "Pemasangan instalasi listrik lengkap untuk rumah modern di Jakarta Barat",
      image: "/api/placeholder/400/300"
    },
    {
      title: "Panel Listrik Industri",
      category: "Industrial",
      description: "Pembuatan dan instalasi panel listrik untuk pabrik di Cengkareng",
      image: "/api/placeholder/400/300"
    },
    {
      title: "Maintenance Gedung Kantor",
      category: "Commercial",
      description: "Perawatan berkala sistem listrik gedung perkantoran 5 lantai",
      image: "/api/placeholder/400/300"
    },
    {
      title: "Instalasi Listrik Ruko",
      category: "Commercial",
      description: "Instalasi listrik untuk 4 unit ruko di area Jakarta Barat",
      image: "/api/placeholder/400/300"
    },
    {
      title: "Perbaikan Listrik Darurat",
      category: "Emergency",
      description: "Penanganan darurat konsleting listrik di rumah tinggal",
      image: "/api/placeholder/400/300"
    },
    {
      title: "Upgrade Panel Listrik",
      category: "Industrial",
      description: "Peningkatan kapasitas panel listrik untuk kebutuhan produksi",
      image: "/api/placeholder/400/300"
    }
  ]

  const advantages = [
    {
      icon: <Award className="w-6 h-6" />,
      title: "Berpengalaman",
      description: "Lebih dari 10 tahun melayani kebutuhan listrik rumah dan industri"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Tim Profesional",
      description: "Teknisi berpengalaman dan bersertifikat keamanan kerja"
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Layanan 24 Jam",
      description: "Siaga melayani kebutuhan darurat kelistrikan kapan saja"
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Bergaransi",
      description: "Garansi layanan untuk kepuasan dan ketenangan pelanggan"
    }
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'
      }`}>
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-400 rounded-lg flex items-center justify-center">
                <span className="text-xl font-bold text-red-600">P</span>
              </div>
              <div className="w-4 h-4 flex items-center justify-center">
                <div className="w-full h-0.5 bg-gradient-to-r from-yellow-400 via-orange-500 to-black"></div>
              </div>
              <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
                <span className="text-xl font-bold text-yellow-400">R</span>
              </div>
              <span className="font-bold text-xl hidden sm:block">Pelita Electrical Raya</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              {['home', 'about', 'services', 'portfolio', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className={`capitalize transition-colors hover:text-yellow-500 ${
                    activeSection === item ? 'text-yellow-500 font-semibold' : 'text-gray-700'
                  }`}
                >
                  {item === 'home' ? 'Beranda' : 
                   item === 'about' ? 'Tentang Kami' :
                   item === 'services' ? 'Layanan' :
                   item === 'portfolio' ? 'Portofolio' : 'Kontak'}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container mx-auto px-4 py-4 space-y-3">
              {['home', 'about', 'services', 'portfolio', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className={`block w-full text-left capitalize py-2 transition-colors hover:text-yellow-500 ${
                    activeSection === item ? 'text-yellow-500 font-semibold' : 'text-gray-700'
                  }`}
                >
                  {item === 'home' ? 'Beranda' : 
                   item === 'about' ? 'Tentang Kami' :
                   item === 'services' ? 'Layanan' :
                   item === 'portfolio' ? 'Portofolio' : 'Kontak'}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900"></div>
        <div className="absolute inset-0 bg-black opacity-50"></div>
        
        {/* Animated Lightning Effect */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-1 h-32 bg-yellow-400 opacity-20 animate-pulse"></div>
          <div className="absolute top-40 right-20 w-0.5 h-24 bg-yellow-300 opacity-30 animate-pulse delay-75"></div>
          <div className="absolute bottom-40 left-1/4 w-0.5 h-40 bg-yellow-400 opacity-25 animate-pulse delay-150"></div>
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          {/* Logo Hero */}
          <div className="flex justify-center items-center gap-4 mb-8">
            <div className="w-20 h-20 bg-yellow-400 rounded-xl flex items-center justify-center shadow-2xl">
              <span className="text-4xl font-bold text-red-600">P</span>
            </div>
            <div className="w-12 h-12 flex items-center justify-center">
              <div className="w-full h-1 bg-gradient-to-r from-yellow-400 via-orange-500 to-black"></div>
            </div>
            <div className="w-20 h-20 bg-red-600 rounded-xl flex items-center justify-center shadow-2xl">
              <span className="text-4xl font-bold text-yellow-400">R</span>
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in-up">
            Pelita Electrical Raya
          </h1>
          
          <h2 className="text-xl md:text-2xl mb-8 text-yellow-300 animate-fade-in-up delay-100">
            Solusi Listrik Profesional dan Terpercaya
          </h2>
          
          <p className="text-lg md:text-xl mb-12 max-w-3xl mx-auto text-gray-300 animate-fade-in-up delay-200">
            Instalasi, maintenance, dan pengadaan material listrik untuk rumah & industri. 
            Aman, cepat, dan bergaransi.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up delay-300">
            <Button 
              onClick={handleWhatsAppClick}
              size="lg"
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg font-semibold shadow-xl transform transition hover:scale-105"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Hubungi Kami Sekarang
            </Button>
            <Button 
              onClick={handleCallClick}
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 text-lg font-semibold shadow-xl transform transition hover:scale-105"
            >
              <Phone className="w-5 h-5 mr-2" />
              +62 813 8069 0076
            </Button>
          </div>

          {/* Contact Info Bar */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
              <Phone className="w-4 h-4 mx-auto mb-1" />
              <p>Telepon</p>
              <p className="font-semibold">+62 813 8069 0076</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
              <MessageCircle className="w-4 h-4 mx-auto mb-1" />
              <p>WhatsApp</p>
              <p className="font-semibold">+62 813 8069 0076</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
              <Mail className="w-4 h-4 mx-auto mb-1" />
              <p>Email</p>
              <p className="font-semibold text-xs">pelitaelectricalraya@gmail.com</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
              <Clock className="w-4 h-4 mx-auto mb-1" />
              <p>Layanan</p>
              <p className="font-semibold">24 Jam</p>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronRight className="w-6 h-6 text-white rotate-90" />
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-yellow-100 text-yellow-800">Tentang Kami</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Profesional dalam Solusi Kelistrikan
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Pelita Electrical Raya telah berpengalaman lebih dari 10 tahun melayani kebutuhan instalasi dan maintenance listrik 
              untuk rumah tangga, kantor, dan industri di seluruh Jakarta.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">Visi Kami</h3>
                  <p className="text-gray-600">
                    Menjadi penyedia jasa kelistrikan terpercaya di Indonesia yang memberikan solusi 
                    aman, efisien, dan berkualitas tinggi untuk setiap pelanggan.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">Misi Kami</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>Memberikan pelayanan terbaik dengan standar keamanan internasional</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>Menyediakan material listrik berkualitas dengan harga kompetitif</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>Siaga 24 jam untuk kebutuhan darurat kelistrikan</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>Meningkatkan kesadaran akan keamanan instalasi listrik</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {advantages.map((advantage, index) => (
                <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-0">
                    <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4 text-yellow-600">
                      {advantage.icon}
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">{advantage.title}</h4>
                    <p className="text-sm text-gray-600">{advantage.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-blue-100 text-blue-800">Layanan Kami</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Solusi Kelistrikan Lengkap
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Kami menyediakan berbagai layanan kelistrikan untuk memenuhi kebutuhan rumah, kantor, dan industri Anda.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center mb-6 text-white group-hover:scale-110 transition-transform">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    onClick={handleWhatsAppClick}
                    variant="outline" 
                    className="w-full mt-6 group-hover:bg-yellow-500 group-hover:text-white group-hover:border-yellow-500 transition-colors"
                  >
                    Pelajari Lebih Lanjut
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-green-100 text-green-800">Portofolio</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Proyek-Proyek Kami
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Berhasil menyelesaikan ratusan proyek kelistrikan dengan hasil memuaskan.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {portfolioItems.map((item, index) => (
              <Card key={index} className="group overflow-hidden hover:shadow-xl transition-all duration-300">
                <div className="aspect-video bg-gradient-to-br from-blue-100 to-yellow-100 relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Zap className="w-16 h-16 text-blue-500 opacity-50" />
                  </div>
                  <Badge className="absolute top-4 left-4 bg-white/90 text-gray-800">
                    {item.category}
                  </Badge>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  <Button 
                    onClick={handleWhatsAppClick}
                    variant="outline" 
                    size="sm"
                    className="group-hover:bg-yellow-500 group-hover:text-white group-hover:border-yellow-500 transition-colors"
                  >
                    Lihat Detail
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-red-100 text-red-800">Kontak Kami</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Hubungi Kami Sekarang
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Siap membantu kebutuhan kelistrikan Anda. Hubungi kami untuk konsultasi gratis.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Kirim Pesan</h3>
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nama Lengkap
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                    placeholder="Masukkan nama Anda"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                    placeholder="email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Pesan
                  </label>
                  <textarea
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                    placeholder="Jelaskan kebutuhan Anda..."
                  />
                </div>
                <Button 
                  type="submit"
                  className="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-3"
                  onClick={(e) => {
                    e.preventDefault()
                    toast.success('Pesan Anda akan segera kami proses!')
                    handleWhatsAppClick()
                  }}
                >
                  Kirim Pesan
                  <MessageCircle className="w-4 h-4 ml-2" />
                </Button>
              </form>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              <Card className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Informasi Kontak</h3>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-6 h-6 text-yellow-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Alamat</h4>
                      <p className="text-gray-600">
                        Jalan Masjid Nurul Huda 33 RT.1/RW.1<br />
                        Cengkareng Timur, Cengkareng<br />
                        Jakarta Barat, DKI Jakarta 11730A
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Phone className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Telepon & WhatsApp</h4>
                      <p className="text-gray-600">+62 813 8069 0076</p>
                      <p className="text-sm text-gray-500">Layanan 24 Jam</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Mail className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Email</h4>
                      <p className="text-gray-600">pelitaelectricalraya@gmail.com</p>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Emergency Contact */}
              <Card className="p-6 bg-red-50 border-red-200">
                <div className="flex items-center gap-3 mb-4">
                  <AlertCircle className="w-6 h-6 text-red-600" />
                  <h3 className="text-xl font-bold text-red-800">Layanan Darurat 24 Jam</h3>
                </div>
                <p className="text-red-700 mb-4">
                  Untuk keadaan darurat kelistrikan, hubungi kami segera!
                </p>
                <Button 
                  onClick={handleCallClick}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Hubungi Darurat
                </Button>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 to-blue-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Percayakan Kebutuhan Listrik Anda pada Ahlinya
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Pelita Electrical Raya – Aman, Cepat, dan Profesional
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleWhatsAppClick}
              size="lg"
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg font-semibold"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Konsultasi Gratis
            </Button>
            <Button 
              onClick={handleCallClick}
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 text-lg font-semibold"
            >
              <Phone className="w-5 h-5 mr-2" />
              Hubungi Sekarang
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            {/* Company Info */}
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-yellow-400 rounded-lg flex items-center justify-center">
                  <span className="text-xl font-bold text-red-600">P</span>
                </div>
                <div className="w-4 h-4 flex items-center justify-center">
                  <div className="w-full h-0.5 bg-gradient-to-r from-yellow-400 via-orange-500 to-black"></div>
                </div>
                <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-xl font-bold text-yellow-400">R</span>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-2">Pelita Electrical Raya</h3>
              <p className="text-gray-400 mb-4">
                Solusi listrik profesional untuk rumah dan industri. 
                Aman, cepat, dan bergaransi.
              </p>
              <p className="text-sm text-gray-500">
                © 2025 Pelita Electrical Raya. Seluruh Hak Dilindungi.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Layanan Cepat</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => scrollToSection('home')} className="hover:text-yellow-400">Beranda</button></li>
                <li><button onClick={() => scrollToSection('about')} className="hover:text-yellow-400">Tentang Kami</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-yellow-400">Layanan</button></li>
                <li><button onClick={() => scrollToSection('portfolio')} className="hover:text-yellow-400">Portofolio</button></li>
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-yellow-400">Kontak</button></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-semibold mb-4">Hubungi Kami</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  +62 813 8069 0076
                </li>
                <li className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp Available
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  pelitaelectricalraya@gmail.com
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Jakarta Barat
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
            <p>
              Website ini dibuat dan dikelola sendiri oleh Pelita Electrical Raya<br />
              Layanan 24 Jam • Siaga Darurat • Bergaransi
            </p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <button
        onClick={handleWhatsAppClick}
        className="fixed bottom-6 right-6 w-14 h-14 bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg flex items-center justify-center z-40 hover:scale-110 transition-transform"
        aria-label="WhatsApp"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {/* Custom Styles */}
      <style jsx>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out forwards;
        }
        
        .delay-100 {
          animation-delay: 0.1s;
        }
        
        .delay-200 {
          animation-delay: 0.2s;
        }
        
        .delay-300 {
          animation-delay: 0.3s;
        }
      `}</style>
    </div>
  )
}