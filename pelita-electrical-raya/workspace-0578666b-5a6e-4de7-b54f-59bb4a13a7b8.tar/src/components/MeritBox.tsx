'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Plus, Heart, Star, Wifi, WifiOff } from 'lucide-react'
import { toast } from 'sonner'

interface MeritData {
  totalMerit: number
  id: string
}

export default function MeritBox() {
  const [meritData, setMeritData] = useState<MeritData | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isAddingMerit, setIsAddingMerit] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [socket, setSocket] = useState<any>(null)

  const fetchMeritData = async () => {
    try {
      const response = await fetch('/api/merit')
      if (response.ok) {
        const data = await response.json()
        setMeritData(data)
      }
    } catch (error) {
      console.error('Failed to fetch merit data:', error)
    }
  }

  const addMerit = async () => {
    if (isAddingMerit) return
    
    setIsAddingMerit(true)
    try {
      const response = await fetch('/api/merit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount: 1 }),
      })

      if (response.ok) {
        const data = await response.json()
        setMeritData(data)
        toast.success('Merit added successfully! 🎉')
      } else {
        toast.error('Failed to add merit')
      }
    } catch (error) {
      console.error('Failed to add merit:', error)
      toast.error('Failed to add merit')
    } finally {
      setIsAddingMerit(false)
    }
  }

  useEffect(() => {
    // Initial data fetch
    fetchMeritData()

    // WebSocket connection
    const connectWebSocket = () => {
      try {
        const ws = new (window as any).io()
        
        ws.on('connect', () => {
          console.log('Connected to WebSocket')
          setIsConnected(true)
          setSocket(ws)
        })

        ws.on('disconnect', () => {
          console.log('Disconnected from WebSocket')
          setIsConnected(false)
        })

        ws.on('merit-updated', (data: { totalMerit: number }) => {
          console.log('Received merit update:', data)
          setMeritData(prev => prev ? { ...prev, totalMerit: data.totalMerit } : null)
        })

        ws.on('connect_error', (error: any) => {
          console.error('WebSocket connection error:', error)
          setIsConnected(false)
        })

        return ws
      } catch (error) {
        console.error('Failed to connect to WebSocket:', error)
        setIsConnected(false)
        return null
      }
    }

    const wsInstance = connectWebSocket()

    // Fallback polling for when WebSocket is not available
    const interval = setInterval(() => {
      if (!isConnected) {
        fetchMeritData()
      }
    }, 5000)

    return () => {
      if (wsInstance) {
        wsInstance.disconnect()
      }
      clearInterval(interval)
    }
  }, [isConnected])

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-8">
          <div className="flex justify-center items-center gap-2 mb-4">
            <div className="w-16 h-16 bg-yellow-400 rounded-lg flex items-center justify-center">
              <span className="text-2xl font-bold text-red-600">P</span>
            </div>
            <div className="w-8 h-8 flex items-center justify-center">
              <div className="w-full h-1 bg-gradient-to-r from-yellow-400 via-orange-500 to-black"></div>
            </div>
            <div className="w-16 h-16 bg-red-600 rounded-lg flex items-center justify-center">
              <span className="text-2xl font-bold text-yellow-400">R</span>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">PELITA ELECTRICAL RAYA</h1>
          <p className="text-gray-600">Shared Merit Box</p>
          
          {/* Connection Status */}
          <div className="flex items-center justify-center gap-2 mt-2">
            {isConnected ? (
              <Badge variant="secondary" className="text-green-600">
                <Wifi className="w-3 h-3 mr-1" />
                Live Updates
              </Badge>
            ) : (
              <Badge variant="outline" className="text-gray-500">
                <WifiOff className="w-3 h-3 mr-1" />
                Polling Mode
              </Badge>
            )}
          </div>
        </div>

        {/* Main Merit Box */}
        <Card className="mb-8 shadow-lg border-2 border-orange-200">
          <CardHeader className="text-center bg-gradient-to-r from-orange-100 to-yellow-100">
            <CardTitle className="text-2xl font-bold text-gray-800 flex items-center justify-center gap-2">
              <Star className="w-6 h-6 text-yellow-500" />
              Total Merit Points
              <Star className="w-6 h-6 text-yellow-500" />
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center py-8">
            {meritData ? (
              <div className="space-y-6">
                <div className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-yellow-500">
                  {meritData.totalMerit.toLocaleString()}
                </div>
                <Badge variant="secondary" className="text-lg px-4 py-2">
                  <Heart className="w-4 h-4 mr-2 text-red-500" />
                  Community Merit
                </Badge>
                <Button 
                  onClick={addMerit}
                  disabled={isAddingMerit}
                  size="lg"
                  className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white font-bold px-8 py-4 text-lg shadow-lg transform transition hover:scale-105"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  {isAddingMerit ? 'Adding...' : '+1 Add Merit'}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="text-2xl text-gray-400">Loading...</div>
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto"></div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Info Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-800">How it Works</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span>Click the "+1 Add Merit" button to contribute</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span>Each click adds 1 merit point to the shared pool</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span>Watch the total grow in real-time</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-800">Community Spirit</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                This merit box represents our collective positive energy and community support. 
                Every contribution matters!
              </p>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span className="text-green-500">●</span>
                <span>{isConnected ? 'Live real-time updates' : 'Updates every 5 seconds'}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Link */}
        <div className="text-center mt-8">
          <Button 
            variant="outline" 
            onClick={() => window.location.href = '/admin'}
            className="text-gray-600 hover:text-gray-800"
          >
            Admin Panel
          </Button>
        </div>
      </div>
    </div>
  )
}