# 🌐 Panduan Lengkap Hosting Gratis untuk Pelita Electrical Raya

## 📋 Overview
Website Pelita Electrical Raya sudah siap dipublikasikan dengan hosting gratis selamanya menggunakan GitHub Pages, Cloudflare, dan layanan gratis lainnya.

## 🚀 Langkah 1: GitHub Pages (Hosting Gratis)

### 1.1 Setup Repository
```bash
# Fork repository ini ke akun GitHub Anda
# Atau clone jika Anda memiliki akses
git clone https://github.com/username/pelita-electrical-rayawebsite.git
cd pelita-electrical-rayawebsite
```

### 1.2 Build & Deploy
```bash
# Install dependencies
npm install

# Build untuk production
npm run build

# Deploy ke GitHub Pages
./deploy.sh
```

### 1.3 Aktifkan GitHub Pages
1. Go to repository Settings → Pages
2. Source: Deploy from a branch
3. Branch: gh-pages / (root)
4. Save

## 🌐 Langkah 2: Domain Gratis (Freenom)

### 2.1 Dapatkan Domain Gratis
1. Kunjungi [Freenom](https://www.freenom.com/)
2. Search domain: `pelitaelectricalraya`
3. Pilih ekstensi gratis (.tk, .ml, .ga, .cf, .gq)
4. Registrasi dengan email valid
5. Pilih periode 12 bulan (bisa diperpanjang gratis)

### 2.2 Konfigurasi DNS
Setelah mendapatkan domain, setup DNS records:

```
Type: CNAME
Name: @
Target: pelitaelectricalraya.github.io
TTL: 3600

Type: CNAME  
Name: www
Target: pelitaelectricalraya.github.io
TTL: 3600
```

## 🔒 Langkah 3: Cloudflare (DNS & Proxy Gratis)

### 3.1 Setup Cloudflare
1. Daftar di [Cloudflare](https://www.cloudflare.com/)
2. Add site: masukkan domain dari Freenom
3. Pilih plan Free
4. Update nameserver di Freenom:
   - `ns1.cloudflare.com`
   - `ns2.cloudflare.com`

### 3.2 Konfigurasi DNS Records
Di Cloudflare DNS dashboard:
```
Type: CNAME
Name: @
Target: pelitaelectricalraya.github.io
Proxy status: Proxied (orange cloud)
TTL: Auto

Type: CNAME
Name: www  
Target: pelitaelectricalraya.github.io
Proxy status: Proxied (orange cloud)
TTL: Auto
```

### 3.3 SSL Certificate
- SSL/TLS → Overview: Full (strict)
- Edge Certificates: Always Use HTTPS

## 📧 Langkah 4: Email Profesional Gratis (ImprovMX)

### 4.1 Setup ImprovMX
1. Kunjungi [ImprovMX](https://improvmx.com/)
2. Add domain: `pelitaelectricalraya.tk`
3. Create email forwarding:
   - From: `info@pelitaelectricalraya.tk`
   - To: `pelitaelectricalraya@gmail.com`
   - From: `admin@pelitaelectricalraya.tk`
   - To: `pelitaelectricalraya@gmail.com`

### 4.2 Update MX Records di Cloudflare
```
Type: MX
Name: @
Server: mx1.improvmx.com
Priority: 10
Proxy status: DNS only (grey cloud)

Type: MX
Name: @  
Server: mx2.improvmx.com
Priority: 20
Proxy status: DNS only (grey cloud)
```

## 📱 Langkah 5: Mobile Optimization & Testing

### 5.1 Testing Tools
- Google PageSpeed Insights
- GTmetrix
- Mobile-Friendly Test (Google)

### 5.2 SEO Checklist
- Meta tags sudah teroptimasi
- Open Graph tags sudah lengkap
- Twitter Card sudah setup
- Schema.org markup sudah ada

## 🔧 Troubleshooting

### Common Issues & Solutions

#### 1. Build Errors
```bash
# Clear cache
rm -rf .next out node_modules
npm install
npm run build
```

#### 2. GitHub Pages 404
- Pastikan branch `gh-pages` sudah ada
- Check repository Settings → Pages configuration
- Verify `.nojekyll` file exists in `out/` folder

#### 3. Domain Not Pointing
- Check DNS propagation (bisa 24-48 jam)
- Verify nameserver at Freenom
- Check Cloudflare DNS records

#### 4. SSL Certificate Issues
- Wait 24 hours for SSL to activate
- Check SSL/TLS settings in Cloudflare
- Force HTTPS redirect

## 📊 Monitoring & Analytics

### Google Analytics (Gratis)
1. Buat account di [Google Analytics](https://analytics.google.com/)
2. Setup property untuk website Anda
3. Add tracking code ke `src/app/layout.tsx`

### Google Search Console
1. Add property di [Search Console](https://search.google.com/)
2. Verify domain ownership
3. Submit sitemap: `yourdomain.com/sitemap.xml`

## 🎨 Kustomisasi Lanjutan

### Mengubah Warna Tema
Edit `src/app/globals.css`:
```css
:root {
  --primary: #002B5B;      /* Biru tua */
  --secondary: #FFD700;    /* Kuning emas */
  --accent: #E63946;       /* Merah aksen */
}
```

### Menambah Portfolio Items
Edit `src/components/PelitaElectricalWebsite.tsx`:
```typescript
const portfolioItems = [
  {
    title: "Nama Proyek Baru",
    category: "Residential", 
    description: "Deskripsi proyek...",
    image: "/path/to/image.jpg"
  }
]
```

### Update Contact Information
Edit constants di component utama:
```typescript
const contactInfo = {
  phone: "+62 813 8069 0076",
  email: "pelitaelectricalraya@gmail.com",
  address: "Jalan Masjid Nurul Huda 33..."
}
```

## 📞 Support & Maintenance

### Regular Maintenance
- Update dependencies setiap 3 bulan
- Backup content dan images
- Monitor website performance
- Update portfolio items regularly

### Contact for Support
- **WhatsApp**: +62 813 8069 0076
- **Email**: pelitaelectricalraya@gmail.com
- **Address**: Jakarta Barat

## 💡 Tips Tambahan

### Performance Optimization
- Compress images sebelum upload
- Use WebP format untuk images
- Enable caching di Cloudflare
- Minimize CSS dan JS files

### Security Best Practices
- HTTPS selalu aktif (Cloudflare)
- Regular backup
- Update dependencies
- Monitor suspicious activity

### Content Marketing
- Regular blog updates tentang listrik
- Customer testimonials
- Project case studies
- Social media integration

---

## 🎉 Selamat! Website Anda Sudah Online

Website Pelita Electrical Raya sekarang sudah online dengan:
- ✅ Hosting gratis selamanya (GitHub Pages)
- ✅ Domain gratis (Freenom)
- ✅ SSL certificate (Cloudflare)
- ✅ Email profesional (ImprovMX)
- ✅ CDN global (Cloudflare)
- ✅ Mobile responsive
- ✅ SEO optimized
- ✅ Fast loading

**URL Final**: `https://pelitaelectricalraya.tk` (atau domain pilihan Anda)

### 📞 Need Help?
Hubungi kami: +62 813 8069 0076

---

*© 2025 Pelita Electrical Raya. Website ini dibuat dan dikelola sendiri oleh Pelita Electrical Raya.*