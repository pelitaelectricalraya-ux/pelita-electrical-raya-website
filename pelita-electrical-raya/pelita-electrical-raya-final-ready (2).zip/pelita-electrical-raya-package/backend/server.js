const express = require('express');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(path.join(__dirname,'../databases/pelita.sqlite'));

const app = express();
const port = process.env.PORT || 8080;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'pelita_secret_key_change_me',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: (process.env.SESSION_SECURE === 'true') } // set via SESSION_SECURE=true when using HTTPS
}));
app.use(express.static(path.join(__dirname,'../frontend')));

// Simple user table initialization (runs on start if not exists)
db.serialize(()=>{
  db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT);");
  db.get("SELECT count(*) as c FROM users", (e,r)=>{
    if(r && r.c === 0){
      // create default admin user. Password can be overridden with ADMIN_PASSWORD env var
      const saltRounds = 10;
      const defaultPassword = process.env.ADMIN_PASSWORD || 'Administrator123#';
      bcrypt.hash(defaultPassword, saltRounds, (err, hash)=>{
        if(!err) db.run("INSERT INTO users (username,password) VALUES (?,?)", ['admin', hash]);
      });
    }
  });
});

// Auth helpers
function ensureAuth(req,res,next){
  if(req.session && req.session.user) return next();
  res.status(401).json({error:'unauthorized'});
}

// Public API
app.get('/api/status', (req,res)=> res.json({status:'ok', service:'pelita-electrical-raya'}));
app.post('/api/contact', (req,res)=> {
  const { name, email, message } = req.body;
  db.run("INSERT INTO contacts (name,email,message,created_at) VALUES (?,?,?,datetime('now'))", [name,email,message], function(err){
    if(err) return res.status(500).json({error:'db_error'});
    res.json({saved:true,id:this.lastID});
  });
});

// Auth endpoints
app.post('/api/auth/login', (req,res)=>{
  const { username, password } = req.body;
  db.get("SELECT id,username,password FROM users WHERE username = ?", [username], (err,row)=>{
    if(err) return res.status(500).json({error:'db_error'});
    if(!row) return res.status(401).json({error:'invalid'});
    bcrypt.compare(password, row.password, (e,matched)=>{
      if(matched){
        req.session.user = {id: row.id, username: row.username};
        res.json({ok:true});
      } else res.status(401).json({error:'invalid'});
    });
  });
});
app.post('/api/auth/logout', (req,res)=>{
  req.session.destroy(()=> res.json({ok:true}));
});
app.get('/api/auth/me', (req,res)=>{
  if(req.session && req.session.user) res.json({user:req.session.user});
  else res.status(401).json({error:'unauthorized'});
});

// Admin endpoints (protected)
app.get('/api/admin/summary', ensureAuth, (req,res)=>{
  db.get("SELECT count(*) as c FROM contacts", (e,r1)=>{
    db.get("SELECT count(*) as p FROM projects", (e2,r2)=>{
      res.json({contacts: r1.c, projects: r2.p});
    });
  });
});
app.get('/api/admin/contacts', ensureAuth, (req,res)=>{
  db.all("SELECT id,name,email,message,created_at FROM contacts ORDER BY created_at DESC", (e,rows)=>{
    res.json(rows);
  });
});
// Projects CRUD
app.get('/api/admin/projects', ensureAuth, (req,res)=>{
  db.all("SELECT id,title,description,year FROM projects ORDER BY year DESC", (e,rows)=> res.json(rows));
});
app.post('/api/admin/projects', ensureAuth, (req,res)=>{
  const { title, description, year } = req.body;
  db.run("INSERT INTO projects (title,description,year) VALUES (?,?,?)", [title,description,year], function(err){
    if(err) return res.status(500).json({error:'db_error'});
    res.json({id:this.lastID});
  });
});
app.put('/api/admin/projects/:id', ensureAuth, (req,res)=>{
  const id = req.params.id;
  const { title, description, year } = req.body;
  db.run("UPDATE projects SET title=?, description=?, year=? WHERE id=?", [title,description,year,id], function(err){
    if(err) return res.status(500).json({error:'db_error'});
    res.json({updated:true});
  });
});
app.delete('/api/admin/projects/:id', ensureAuth, (req,res)=>{
  const id = req.params.id;
  db.run("DELETE FROM projects WHERE id=?", [id], function(err){
    if(err) return res.status(500).json({error:'db_error'});
    res.json({deleted:true});
  });
});

// Serve admin React app (we'll put files in /admin_build)
app.use('/admin', express.static(path.join(__dirname,'../admin_build')));

// Fallback to frontend
app.get('*', (req,res)=>{
  res.sendFile(path.join(__dirname,'../frontend/index.html'));
});

app.listen(port, ()=> console.log('Server running on', port));
