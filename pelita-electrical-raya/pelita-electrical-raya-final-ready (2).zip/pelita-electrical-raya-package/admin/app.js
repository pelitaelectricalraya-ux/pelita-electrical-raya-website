// Minimal admin UI that talks to /api endpoints
async function fetchData(){ 
  const res = await fetch('/api/admin/summary'); 
  const data = await res.json();
  document.getElementById('app').innerHTML = `
    <div class="bg-white p-4 rounded shadow">
      <h2 class="font-bold">Summary</h2>
      <p>Contacts: ${data.contacts}</p>
      <p>Projects: ${data.projects}</p>
    </div>
    <div class="mt-4 bg-white p-4 rounded shadow">
      <h3 class="font-bold">Contacts</h3>
      <div id="contacts"></div>
    </div>
  `;
  const c = await fetch('/api/admin/contacts');
  const contacts = await c.json();
  document.getElementById('contacts').innerHTML = contacts.map(x=>`<div class="p-2 border-b">${x.name} - ${x.email}<div class="text-sm">${x.message}</div></div>`).join('');
}
fetchData();
