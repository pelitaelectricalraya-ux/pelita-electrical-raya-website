Backup & Restore SOP
- SQLite backup: copy databases/pelita.sqlite to secure storage.
- Postgres backup: pg_dump -U pelita -h localhost -Fc pelita_db > pelita_db.dump
- To restore Postgres: pg_restore -U pelita -d pelita_db pelita_db.dump
- Docker volumes: stop containers, backup volumes as needed.
