#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "Running Pelita Electrical Raya setup (Linux)"
# Ensure running as root for hosts modification
if [ "$EUID" -ne 0 ]; then
  echo "Warning: some operations may require sudo. Re-run with sudo if needed."
fi

# Create .env if not exists
if [ ! -f "$ROOT/.env" ]; then
  echo "Writing .env with provided defaults"
  cat > "$ROOT/.env" <<EOF
ADMIN_PASSWORD=Administrator123#
DOMAIN=pelitaelectricalraya
SESSION_SECURE=false
SESSION_SECRET=please_change_this_to_a_strong_random_value
EOF
else
  echo ".env already exists; leaving it unchanged."
fi

# Add hosts entry for internal domain (maps to localhost)
if ! grep -q "pelitaelectricalraya" /etc/hosts 2>/dev/null; then
  echo "Adding hosts entry for pelitaelectricalraya -> 127.0.0.1"
  echo "127.0.0.1 pelitaelectricalraya" | sudo tee -a /etc/hosts
else
  echo "Hosts entry for pelitaelectricalraya already present."
fi

# Start docker compose
if command -v docker >/dev/null 2>&1 && command -v docker-compose >/dev/null 2>&1; then
  echo "Starting docker compose..."
  docker compose up --build -d
  echo "Containers started."
else
  echo "Docker or Docker Compose not found. Please install Docker and try again."
fi

echo "Setup complete. Visit http://pelitaelectricalraya or http://localhost"
