
const e = React.createElement;
const { useState, useEffect } = React;

function Login({onLogin}){
  const [u,setU] = useState('admin');
  const [p,setP] = useState('');
  const [err,setErr] = useState('');
  async function submit(evn){
    evn.preventDefault();
    try{
      await axios.post('/api/auth/login',{username:u,password:p});
      onLogin();
    }catch(err){
      setErr('Login gagal');
    }
  }
  return e('div',{className:'max-w-md mx-auto bg-white p-4 rounded shadow'},
    e('h2',{className:'text-xl font-bold mb-2'},'Admin Login'),
    err && e('div',{className:'text-red-600 mb-2'},err),
    e('form',{onSubmit:submit},
      e('input',{className:'w-full p-2 border mb-2',value:u,onChange:ev=>setU(ev.target.value),placeholder:'username'}),
      e('input',{type:'password',className:'w-full p-2 border mb-2',value:p,onChange:ev=>setP(ev.target.value),placeholder:'password'}),
      e('button',{className:'px-4 py-2 bg-blue-600 text-white rounded'},'Login')
    )
  );
}

function AdminApp(){
  const [authed,setAuthed] = useState(false);
  const [summary,setSummary] = useState(null);
  const [contacts,setContacts] = useState([]);
  const [projects,setProjects] = useState([]);
  const [form,setForm] = useState({title:'',description:'',year:new Date().getFullYear()});

  useEffect(()=>{ checkAuth(); },[]);

  async function checkAuth(){
    try{
      await axios.get('/api/auth/me'); setAuthed(true); loadData();
    }catch(e){ setAuthed(false); }
  }
  async function loadData(){
    const s = await axios.get('/api/admin/summary'); setSummary(s.data);
    const c = await axios.get('/api/admin/contacts'); setContacts(c.data);
    const p = await axios.get('/api/admin/projects'); setProjects(p.data);
  }
  async function logout(){ await axios.post('/api/auth/logout'); setAuthed(false); }
  async function addProject(e){
    e.preventDefault();
    await axios.post('/api/admin/projects', form);
    setForm({title:'',description:'',year:new Date().getFullYear()}); loadData();
  }
  async function delProject(id){ await axios.delete('/api/admin/projects/'+id); loadData(); }

  if(!authed) return e(Login,{onLogin:checkAuth});

  return e('div',{className:'max-w-5xl mx-auto'},
    e('div',{className:'flex justify-between items-center mb-4'},
      e('h1',{className:'text-2xl font-bold'},'Admin Dashboard'),
      e('div',{}, e('button',{className:'px-3 py-1 border', onClick:logout}, 'Logout'))
    ),
    summary && e('div',{className:'grid grid-cols-2 gap-4 mb-4'},
      e('div',{className:'bg-white p-4 rounded shadow'}, e('div',{}, 'Contacts: '+summary.contacts)),
      e('div',{className:'bg-white p-4 rounded shadow'}, e('div',{}, 'Projects: '+summary.projects))
    ),
    e('div',{className:'grid md:grid-cols-2 gap-4'},
      e('div',{className:'bg-white p-4 rounded shadow'},
        e('h2',{},'Contacts'),
        contacts.map(c=> e('div',{className:'border-b p-2'}, [ e('div',{}, c.name+' ('+c.email+')'), e('div',{className:'text-sm text-gray-600'}, c.message) ] ))
      ),
      e('div',{className:'bg-white p-4 rounded shadow'},
        e('h2',{},'Projects'),
        e('form',{onSubmit:addProject, className:'mb-4'},
          e('input',{className:'w-full p-2 border mb-2', placeholder:'Title', value:form.title, onChange:ev=>setForm({...form,title:ev.target.value})}),
          e('textarea',{className:'w-full p-2 border mb-2', placeholder:'Description', value:form.description, onChange:ev=>setForm({...form,description:ev.target.value})}),
          e('input',{className:'w-full p-2 border mb-2', type:'number', value:form.year, onChange:ev=>setForm({...form,year:parseInt(ev.target.value)})}),
          e('button',{className:'px-3 py-1 bg-green-600 text-white rounded'}, 'Add Project')
        ),
        projects.map(p=> e('div',{className:'border-b p-2 flex justify-between items-center'}, [
          e('div',{}, e('div',{}, p.title), e('div',{className:'text-sm text-gray-600'}, p.description)),
          e('div',{}, e('button',{className:'px-2 py-1 text-sm border', onClick:()=>delProject(p.id)}, 'Delete'))
        ]))
      )
    )
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(AdminApp));
