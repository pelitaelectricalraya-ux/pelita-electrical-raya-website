Pelita Electrical Raya - Complete Package (Generated)

What's included:
- frontend/         -> Static website (Tailwind via CDN)
- backend/          -> Node.js Express app template + Dockerfile
- assets/per2025.png-> Logo (provided or placeholder)
- config/           -> nginx and dnsmasq configs for local domain mapping
- mailserver/       -> Mail server deployment notes & templates (Mailcow/Mailu)
- databases/        -> SQLite database and Postgres SQL dump
- docker-compose.yml-> Compose to bring up app, nginx, db, dnsmasq

Important notes:
- This package is designed to run locally or on your own server.
- For real public email delivery and public domain usage, you will need:
  * A real domain name and DNS provider to configure MX, SPF, DKIM, DMARC.
  * Proper TLS certificates (Let's Encrypt or your CA).
  * Mail server hardening for production.

Quick start (local testing):
1. Install Docker & Docker Compose.
2. unzip pelita-electrical-raya.zip
3. cd pelita-electrical-raya-package
4. docker compose up --build -d
5. Visit http://pelitaelectricalraya.tk  (or http://localhost if not using dnsmasq)
   - If dnsmasq is not used, add hosts file entry: 127.0.0.1 pelitaelectricalraya.tk

Contact & support info embedded in site:
Address: Jalan Masjid Nurul Huda 33 RT.1/RW.1 Cengkareng Timur Cengkareng Jakarta Barat DKI Jakarta 11730A
Phone/WhatsApp/SMS: +62 813 8069 0076
Emails: pelitaelectricalraya@gmail.com, support@pelitaelectricalraya.tk, maintenance@pelitaelectricalraya.tk, info@pelitaelectricalraya.tk

Generated: 2025

## Additional Features Added
- Admin panel (admin/) with admin endpoints.
- Expanded DB seed data (SQLite + Postgres dump).
- Mailcow hint & templates in mailserver/ (requires domain).
- Caddyfile & certbot script for Let's Encrypt integration.
- setup.sh to add hosts entry and run docker compose.
- SOP & backup scripts in docs/ and scripts/.


## Admin Authentication
- Default admin user created: username `admin` and password `admin123`. CHANGE THIS PASSWORD before exposing to the public.
- Backend uses express-session and bcrypt for password hashing. For production use HTTPS and set secure cookies, and consider using OAuth2 or a proper identity provider.

## Security Recommendations
- Enable HTTPS (use Caddy or certbot with Let's Encrypt).
- Restrict access to admin panel via firewall or VPN if possible.
- Use strong passwords and rotate credentials.



## IMPORTANT: Admin credentials & HTTPS setup (finalized)
- Default admin username: **admin**
- Default admin password: **oOa-r3vLDKFeCJ%k**  <-- CHANGE THIS PASSWORD immediately.
  - You can override this by creating a `.env` file in the project root with `ADMIN_PASSWORD=your_new_password`
- To enable HTTPS and secure cookies:
  1. Set your domain in `.env` (DOMAIN=yourdomain.tld)
  2. Set `SESSION_SECURE=true` in `.env` and set a strong `SESSION_SECRET`.
  3. Edit `config/Caddyfile` and replace {DOMAIN} with your domain, or generate a Caddyfile dynamically before starting.
  4. Start the stack with Docker Compose. Caddy will obtain TLS certificates automatically for public domains if ports 80/443 are reachable.
  5. Ensure ports 80 and 443 are open and domain points to your server IP.

## Final notes
- After first boot the admin user is created automatically using the ADMIN_PASSWORD value.
- For production deployments, rotate the default password, use HTTPS, and restrict access to admin panel using firewall or VPN.


## FINAL PACKAGE PREPARED FOR YOU
- Admin username: **admin**
- Admin password (as you requested): **Administrator123#**
- Internal host/domain configured: **pelitaelectricalraya** (mapped to 127.0.0.1 by setup scripts)
- OS support: **Linux** and **Windows**. Use `setup.sh` for Linux and `setup.bat` for Windows.
- .env file created at project root with these values (edit before production).

### Quick start (Linux)
1. Place the package on your server and `cd` into the project root.
2. (Optional) Edit `.env` to change values before first run.
3. Run: `sudo ./setup.sh`
4. Open: `http://pelitaelectricalraya` or `http://localhost`

### Quick start (Windows)
1. Extract package folder.
2. Right-click `setup.bat` and "Run as administrator".
3. After Docker starts, visit `http://pelitaelectricalraya` or `http://localhost`.

### Security reminders
- Change `ADMIN_PASSWORD` immediately to a strong random password if you will expose the server publicly.
- If exposing publicly, set `SESSION_SECURE=true` and set a long `SESSION_SECRET` in `.env` and enable HTTPS (Caddy or other reverse proxy).
- For mail delivery, use a public domain and configure DNS (A, MX, SPF, DKIM, DMARC).

