# 🚀 Pelita Electrical Raya - 快速部署指南

## 📦 文件包内容
您已下载的 `pelita-electrical-raya-ultimate.tar.gz` 包含：
- ✅ 完整的网站前端
- ✅ 后端API系统
- ✅ 管理面板
- ✅ 邮件系统配置
- ✅ 本地DNS设置
- ✅ 自动部署脚本

## 🎯 一键部署（推荐）

### Linux/macOS 用户：
```bash
# 1. 解压文件
tar -xzf pelita-electrical-raya-ultimate.tar.gz
cd pelita-electrical-raya-ultimate

# 2. 运行自动安装
chmod +x install-linux.sh
./install-linux.sh

# 3. 访问网站
# 浏览器打开: http://pelitaelectricalraya
```

### Windows 用户：
```cmd
# 1. 解压文件到文件夹
# 2. 双击运行 install-windows.bat
# 3. 浏览器打开: http://pelitaelectricalraya
```

## 🔑 默认登录信息
- **管理面板**: http://pelitaelectricalraya/admin
- **用户名**: admin
- **密码**: Administrator123#

## 📱 快速测试
安装完成后，您可以：
1. 浏览公司主页
2. 查看服务项目
3. 提交联系表单
4. 登录管理面板管理内容

## 🛠️ 手动部署（可选）

如果自动脚本无法运行，可以手动部署：

### 前端部署
```bash
cd frontend
npm install
npm run build
# 将 build 文件夹复制到 Web 服务器
```

### 后端部署
```bash
cd backend
npm install
npm start
# 后端将在 http://localhost:5000 运行
```

### 管理面板部署
```bash
cd admin-panel
npm install
npm run build
# 将 build 文件夹部署到 /admin 路径
```

## 🌐 访问地址
- **主页**: http://pelitaelectricalraya
- **管理面板**: http://pelitaelectricalraya/admin
- **API**: http://pelitaelectricalraya/api

## 📞 联系信息
- **电话**: +62 813 8069 0076
- **邮箱**: pelitaelectricalraya@gmail.com
- **地址**: Perum. Permata Cibitung Blok C2 No.25, RT.004/RW.018, Wanajaya, Kec. Cibitung, Kabupaten Bekasi, Jawa Barat 17520

## 🔧 故障排除

### 端口占用
如果遇到端口占用问题：
```bash
# 检查端口使用
sudo netstat -tulpn | grep :80
# 停止其他服务
sudo systemctl stop nginx apache2
```

### 权限问题
```bash
# 给予脚本执行权限
chmod +x *.sh
# 给予文件夹权限
sudo chown -R $USER:$USER /var/www/pelita
```

### DNS 问题
如果无法访问 pelitaelectricalraya：
1. 检查 `/etc/hosts` 文件是否包含：
   ```
   127.0.0.1 pelitaelectricalraya
   ```
2. 重启网络服务：
   ```bash
   sudo systemctl restart systemd-resolved
   ```

## 📚 完整文档
详细文档请参考：
- `README.md` - 完整项目说明
- `docs/` - 详细技术文档
- `docs/id/` - 印尼语文档

## 🎉 完成！
您现在拥有一个功能完整的电气公司网站系统！

---
*创建时间: 2025-06-17*  
*版本: 1.0*  
*支持: Pelita Electrical Raya Team*