# Installation Guide - Pelita Electrical Raya

## 🇮🇩 Bahasa Indonesia

### Persyaratan Sistem
- OS: Linux (Ubuntu 20.04+), Windows 10+, macOS 10.15+
- Node.js 16+ atau Python 3.8+
- SQLite 3
- 2GB RAM minimum
- 5GB disk space

### Instalasi Linux/macOS
```bash
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
./scripts/setup.sh

# 3. Access website
open http://pelitaelectricalraya
```

### Instalasi Windows
```cmd
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
scripts\setup.bat

# 3. Access website
start http://pelitaelectricalraya
```

### Konfigurasi Lanjutan
Edit file `.env` untuk mengubah:
- DOMAIN: Domain untuk website
- ADMIN_PASSWORD: Password admin
- SESSION_SECRET: Secret key untuk session
- MAIL_HOST/PORT: Konfigurasi email server

### Troubleshooting
- Port 8080/5000 sudah digunakan: Kill process atau ubah port
- Permission denied: Gunakan sudo (Linux) atau Run as Administrator (Windows)
- Node.js tidak ditemukan: Install dari https://nodejs.org

## 🇬🇧 English

### System Requirements
- OS: Linux (Ubuntu 20.04+), Windows 10+, macOS 10.15+
- Node.js 16+ or Python 3.8+
- SQLite 3
- 2GB RAM minimum
- 5GB disk space

### Linux/macOS Installation
```bash
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
./scripts/setup.sh

# 3. Access website
open http://pelitaelectricalraya
```

### Windows Installation
```cmd
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
scripts\setup.bat

# 3. Access website
start http://pelitaelectricalraya
```

### Advanced Configuration
Edit `.env` file to change:
- DOMAIN: Website domain
- ADMIN_PASSWORD: Admin password
- SESSION_SECRET: Session secret key
- MAIL_HOST/PORT: Email server configuration

### Troubleshooting
- Port 8080/5000 in use: Kill process or change port
- Permission denied: Use sudo (Linux) or Run as Administrator (Windows)
- Node.js not found: Install from https://nodejs.org
