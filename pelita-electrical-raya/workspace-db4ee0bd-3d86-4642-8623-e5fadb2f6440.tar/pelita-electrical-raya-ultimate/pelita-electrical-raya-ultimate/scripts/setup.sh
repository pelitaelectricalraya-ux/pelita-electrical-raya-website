#!/bin/bash

# Pelita Electrical Raya - Setup Script for Linux
# This script sets up the complete environment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="Pelita Electrical Raya"
DOMAIN="pelitaelectricalraya"
ADMIN_USER="admin"
ADMIN_PASSWORD="Administrator123#"
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

# Helper functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Check if running as root for system operations
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_warning "Running as root. Some operations will be performed with sudo."
    fi
}

# Detect OS
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/debian_version ]; then
            OS="debian"
            print_info "Detected Debian/Ubuntu system"
        elif [ -f /etc/redhat-release ]; then
            OS="redhat"
            print_info "Detected RedHat/CentOS system"
        else
            OS="linux"
            print_info "Detected Linux system"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
        print_info "Detected macOS system"
    else
        OS="unknown"
        print_warning "Unknown OS: $OSTYPE"
    fi
}

# Install system dependencies
install_dependencies() {
    print_header "Installing System Dependencies"
    
    case $OS in
        "debian")
            print_info "Updating package lists..."
            sudo apt update
            
            print_info "Installing required packages..."
            sudo apt install -y curl wget git nodejs npm sqlite3 nginx certbot python3-certbot-nginx
            
            # Install Docker if not present
            if ! command -v docker &> /dev/null; then
                print_info "Installing Docker..."
                curl -fsSL https://get.docker.com -o get-docker.sh
                sudo sh get-docker.sh
                sudo usermod -aG docker $USER
                rm get-docker.sh
            fi
            
            # Install Docker Compose if not present
            if ! command -v docker-compose &> /dev/null; then
                print_info "Installing Docker Compose..."
                sudo apt install -y docker-compose-plugin
            fi
            ;;
            
        "redhat")
            print_info "Installing required packages..."
            sudo yum update -y
            sudo yum install -y curl wget git nodejs npm sqlite nginx
            ;;
            
        "macos")
            print_info "Checking for Homebrew..."
            if ! command -v brew &> /dev/null; then
                print_info "Installing Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            
            print_info "Installing packages with Homebrew..."
            brew install node npm sqlite3 nginx
            ;;
            
        *)
            print_error "Unsupported OS for automatic dependency installation"
            print_info "Please install Node.js, npm, sqlite3 manually"
            ;;
    esac
    
    print_success "System dependencies installed"
}

# Setup hosts file
setup_hosts() {
    print_header "Setting Up Local DNS"
    
    if ! grep -q "$DOMAIN" /etc/hosts; then
        print_info "Adding $DOMAIN to hosts file..."
        echo "127.0.0.1 $DOMAIN" | sudo tee -a /etc/hosts
        print_success "Added $DOMAIN to hosts file"
    else
        print_info "$DOMAIN already exists in hosts file"
    fi
}

# Setup environment file
setup_environment() {
    print_header "Setting Up Environment"
    
    if [ ! -f "$PROJECT_ROOT/.env" ]; then
        print_info "Creating .env file..."
        cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env"
        
        # Generate random session secret
        SESSION_SECRET=$(openssl rand -hex 32)
        sed -i "s/please_change_this_to_a_random_secret/$SESSION_SECRET/" "$PROJECT_ROOT/.env"
        
        print_success "Environment file created"
    else
        print_info "Environment file already exists"
    fi
}

# Install Node.js dependencies
install_node_dependencies() {
    print_header "Installing Node.js Dependencies"
    
    # Node.js backend
    if [ -d "$PROJECT_ROOT/backend-node" ]; then
        print_info "Installing Node.js backend dependencies..."
        cd "$PROJECT_ROOT/backend-node"
        npm install
        print_success "Node.js backend dependencies installed"
    fi
    
    # Python backend (optional)
    if [ -d "$PROJECT_ROOT/backend-flask" ]; then
        print_info "Python backend detected. Install with: pip install -r requirements.txt"
    fi
}

# Setup database
setup_database() {
    print_header "Setting Up Database"
    
    # Create database directory
    mkdir -p "$PROJECT_ROOT/backend-node/db"
    mkdir -p "$PROJECT_ROOT/backend-flask/db"
    mkdir -p "$PROJECT_ROOT/databases/backup"
    
    print_success "Database directories created"
}

# Setup SSL certificates (optional)
setup_ssl() {
    print_header "Setting Up SSL Certificates"
    
    if command -v certbot &> /dev/null; then
        print_info "Certbot found. SSL can be configured for public domains."
        print_info "To setup SSL for a public domain, run:"
        print_info "sudo certbot --nginx -d yourdomain.com"
    else
        print_warning "Certbot not found. SSL certificates not configured."
    fi
}

# Create systemd service
create_systemd_service() {
    print_header "Creating Systemd Service"
    
    cat > /tmp/pelita-electrical.service << EOF
[Unit]
Description=Pelita Electrical Raya Backend
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$PROJECT_ROOT/backend-node
Environment=NODE_ENV=production
Environment=PATH=/usr/bin:/usr/local/bin
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    sudo mv /tmp/pelita-electrical.service /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable pelita-electrical.service
    
    print_success "Systemd service created and enabled"
}

# Setup firewall
setup_firewall() {
    print_header "Configuring Firewall"
    
    if command -v ufw &> /dev/null; then
        print_info "Configuring UFW firewall..."
        sudo ufw allow 22/tcp
        sudo ufw allow 80/tcp
        sudo ufw allow 443/tcp
        sudo ufw allow 5000/tcp  # Flask
        sudo ufw allow 8080/tcp  # Node.js
        sudo ufw --force enable
        print_success "Firewall configured"
    else
        print_warning "UFW not found. Please configure firewall manually."
    fi
}

# Start services
start_services() {
    print_header "Starting Services"
    
    # Start Node.js backend
    if [ -f "$PROJECT_ROOT/backend-node/server.js" ]; then
        print_info "Starting Node.js backend..."
        cd "$PROJECT_ROOT/backend-node"
        nohup node server.js > ../logs/backend.log 2>&1 &
        echo $! > ../logs/backend.pid
        print_success "Node.js backend started"
    fi
    
    # Start mock SMTP server
    if [ -f "$PROJECT_ROOT/mailserver/mock_smtp.js" ]; then
        print_info "Starting mock SMTP server..."
        cd "$PROJECT_ROOT/mailserver"
        nohup node mock_smtp.js > ../logs/smtp.log 2>&1 &
        echo $! > ../logs/smtp.pid
        print_success "Mock SMTP server started"
    fi
    
    # Start systemd service
    sudo systemctl start pelita-electrical.service
    print_success "All services started"
}

# Create logs directory
setup_logs() {
    mkdir -p "$PROJECT_ROOT/logs"
    touch "$PROJECT_ROOT/logs/backend.log"
    touch "$PROJECT_ROOT/logs/smtp.log"
    touch "$PROJECT_ROOT/logs/access.log"
}

# Display completion message
show_completion() {
    print_header "Setup Complete!"
    
    echo -e "${GREEN}🎉 Pelita Electrical Raya has been successfully setup!${NC}"
    echo
    echo -e "${BLUE}Access Information:${NC}"
    echo -e "• Website: ${YELLOW}http://$DOMAIN${NC}"
    echo -e "• Admin Panel: ${YELLOW}http://$DOMAIN/admin${NC}"
    echo -e "• API: ${YELLOW}http://$DOMAIN/api${NC}"
    echo
    echo -e "${BLUE}Default Login:${NC}"
    echo -e "• Username: ${YELLOW}$ADMIN_USER${NC}"
    echo -e "• Password: ${YELLOW}$ADMIN_PASSWORD${NC}"
    echo
    echo -e "${BLUE}Service Status:${NC}"
    echo -e "• Backend: ${GREEN}Running on port 8080${NC}"
    echo -e "• SMTP: ${GREEN}Running on port 1025${NC}"
    echo
    echo -e "${BLUE}Useful Commands:${NC}"
    echo -e "• View logs: ${YELLOW}tail -f $PROJECT_ROOT/logs/backend.log${NC}"
    echo -e "• Stop services: ${YELLOW}sudo systemctl stop pelita-electrical${NC}"
    echo -e "• Restart services: ${YELLOW}sudo systemctl restart pelita-electrical${NC}"
    echo
    echo -e "${RED}⚠️  Important Security Notes:${NC}"
    echo -e "• Change the default admin password immediately"
    echo -e "• Configure SSL certificates for production use"
    echo -e "• Setup proper firewall rules"
    echo -e "• Regularly update the system and dependencies"
    echo
    print_success "Setup completed successfully!"
}

# Main execution
main() {
    print_header "$PROJECT_NAME Setup Script"
    print_info "This script will setup the complete Pelita Electrical Raya environment"
    echo
    
    # Check if running in correct directory
    if [ ! -f "$PROJECT_ROOT/.env.example" ]; then
        print_error "Please run this script from the project root directory"
        exit 1
    fi
    
    # Run setup steps
    check_root
    detect_os
    install_dependencies
    setup_hosts
    setup_environment
    install_node_dependencies
    setup_database
    setup_logs
    create_systemd_service
    setup_firewall
    start_services
    setup_ssl
    show_completion
}

# Handle script interruption
trap 'print_error "Setup interrupted"; exit 1' INT

# Run main function
main "$@"