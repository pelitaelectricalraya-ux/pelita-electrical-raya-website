#!/bin/bash

# Pelita Electrical Raya - Backup Script
# This script creates backups of databases and important files

set -e

# Configuration
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BACKUP_DIR="$PROJECT_ROOT/databases/backup"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="pelita_backup_$TIMESTAMP"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_info() {
    echo -e "${YELLOW}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Create backup directory
mkdir -p "$BACKUP_DIR"

print_info "Starting backup process..."

# Backup SQLite databases
print_info "Backing up SQLite databases..."

if [ -f "$PROJECT_ROOT/backend-node/db/pelita.sqlite" ]; then
    cp "$PROJECT_ROOT/backend-node/db/pelita.sqlite" "$BACKUP_DIR/pelita_node_$TIMESTAMP.sqlite"
    print_success "Node.js SQLite database backed up"
fi

if [ -f "$PROJECT_ROOT/backend-flask/db/pelita.sqlite" ]; then
    cp "$PROJECT_ROOT/backend-flask/db/pelita.sqlite" "$BACKUP_DIR/pelita_flask_$TIMESTAMP.sqlite"
    print_success "Flask SQLite database backed up"
fi

# Backup configuration files
print_info "Backing up configuration files..."

mkdir -p "$BACKUP_DIR/$BACKUP_NAME"
cp "$PROJECT_ROOT/.env" "$BACKUP_DIR/$BACKUP_NAME/" 2>/dev/null || true
cp -r "$PROJECT_ROOT/config" "$BACKUP_DIR/$BACKUP_NAME/" 2>/dev/null || true
cp -r "$PROJECT_ROOT/scripts" "$BACKUP_DIR/$BACKUP_NAME/" 2>/dev/null || true

print_success "Configuration files backed up"

# Backup logs (last 7 days)
print_info "Backing up recent logs..."
mkdir -p "$BACKUP_DIR/$BACKUP_NAME/logs"
find "$PROJECT_ROOT/logs" -name "*.log" -mtime -7 -exec cp {} "$BACKUP_DIR/$BACKUP_NAME/logs/" \; 2>/dev/null || true
print_success "Recent logs backed up"

# Create compressed archive
print_info "Creating compressed archive..."
cd "$BACKUP_DIR"
tar -czf "$BACKUP_NAME.tar.gz" "$BACKUP_NAME"
rm -rf "$BACKUP_NAME"

print_success "Backup archive created: $BACKUP_DIR/$BACKUP_NAME.tar.gz"

# Cleanup old backups (keep last 10)
print_info "Cleaning up old backups..."
ls -t "$BACKUP_DIR"/*.tar.gz | tail -n +11 | xargs -r rm
print_success "Old backups cleaned up"

# Display backup information
BACKUP_SIZE=$(du -h "$BACKUP_DIR/$BACKUP_NAME.tar.gz" | cut -f1)
echo
echo "========================================"
echo "Backup Summary"
echo "========================================"
echo "Backup file: $BACKUP_DIR/$BACKUP_NAME.tar.gz"
echo "Size: $BACKUP_SIZE"
echo "Created: $(date)"
echo "========================================"

print_success "Backup completed successfully!"