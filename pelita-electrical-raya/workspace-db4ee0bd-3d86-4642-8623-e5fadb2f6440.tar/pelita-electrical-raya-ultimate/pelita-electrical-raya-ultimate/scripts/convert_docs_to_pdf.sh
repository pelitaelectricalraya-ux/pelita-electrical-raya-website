#!/bin/bash

# Pelita Electrical Raya - Documentation to PDF Converter
# This script converts markdown documentation to PDF using pandoc

set -e

# Configuration
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DOCS_DIR="$PROJECT_ROOT/docs"
OUTPUT_DIR="$PROJECT_ROOT/docs/pdf"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_info() {
    echo -e "${YELLOW}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Check if pandoc is installed
check_dependencies() {
    if ! command -v pandoc &> /dev/null; then
        print_error "pandoc is not installed"
        print_info "Installing pandoc..."
        
        if [[ "$OSTYPE" == "linux-gnu"* ]]; then
            if command -v apt &> /dev/null; then
                sudo apt update
                sudo apt install -y pandoc texlive-xetex texlive-fonts-recommended texlive-latex-extra
            elif command -v yum &> /dev/null; then
                sudo yum install -y pandoc texlive-xetex
            else
                print_error "Cannot install pandoc automatically. Please install manually."
                exit 1
            fi
        elif [[ "$OSTYPE" == "darwin"* ]]; then
            if command -v brew &> /dev/null; then
                brew install pandoc
                brew install --cask mactex
            else
                print_error "Please install Homebrew first, then: brew install pandoc"
                exit 1
            fi
        else
            print_error "Unsupported OS. Please install pandoc manually."
            exit 1
        fi
    fi
    
    if ! command -v wkhtmltopdf &> /dev/null; then
        print_info "wkhtmltopdf not found. Installing for better PDF conversion..."
        
        if [[ "$OSTYPE" == "linux-gnu"* ]]; then
            if command -v apt &> /dev/null; then
                sudo apt install -y wkhtmltopdf
            fi
        fi
    fi
}

# Create output directory
create_output_dir() {
    mkdir -p "$OUTPUT_DIR"
    print_success "Output directory created: $OUTPUT_DIR"
}

# Convert single markdown to PDF
convert_md_to_pdf() {
    local md_file="$1"
    local filename=$(basename "$md_file" .md)
    local pdf_file="$OUTPUT_DIR/${filename}.pdf"
    
    print_info "Converting $md_file to PDF..."
    
    # Try pandoc first
    if pandoc "$md_file" -o "$pdf_file" --pdf-engine=xelatex -V geometry:margin=1in -V fontsize=12pt 2>/dev/null; then
        print_success "Created $pdf_file"
        return 0
    fi
    
    # Fallback to wkhtmltopdf
    if command -v wkhtmltopdf &> /dev/null; then
        # Convert markdown to HTML first
        local html_file="$OUTPUT_DIR/${filename}.html"
        pandoc "$md_file" -o "$html_file" --standalone 2>/dev/null || {
            # Simple markdown to HTML conversion
            cat > "$html_file" << EOF
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>$(basename "$md_file" .md)</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        h1, h2, h3 { color: #002a60; }
        code { background: #f4f4f4; padding: 2px 4px; border-radius: 3px; }
        pre { background: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }
        blockquote { border-left: 4px solid #004aad; margin: 0; padding-left: 20px; color: #666; }
        table { border-collapse: collapse; width: 100%%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
$(cat "$md_file")
</body>
</html>
EOF
        }
        
        # Convert HTML to PDF
        wkhtmltopdf "$html_file" "$pdf_file" 2>/dev/null && {
            rm "$html_file"
            print_success "Created $pdf_file"
            return 0
        }
    fi
    
    print_error "Failed to convert $md_file"
    return 1
}

# Create combined documentation PDF
create_combined_pdf() {
    print_info "Creating combined documentation PDF..."
    
    local combined_file="$OUTPUT_DIR/Pelita_Electrical_Raya_Documentation.pdf"
    local temp_md="$OUTPUT_DIR/combined_temp.md"
    
    # Create combined markdown file
    cat > "$temp_md" << EOF
# Pelita Electrical Raya - Complete Documentation

Generated on: $(date)

---

EOF
    
    # Add all markdown files
    for md_file in "$DOCS_DIR"/*.md; do
        if [ -f "$md_file" ]; then
            echo "" >> "$temp_md"
            echo "---" >> "$temp_md"
            echo "" >> "$temp_md"
            cat "$md_file" >> "$temp_md"
        fi
    done
    
    # Convert to PDF
    if convert_md_to_pdf "$temp_md"; then
        print_success "Combined documentation PDF created: $combined_file"
    fi
    
    # Cleanup
    rm -f "$temp_md"
}

# Main conversion process
main() {
    echo "========================================"
    echo "Pelita Electrical Raya - PDF Converter"
    echo "========================================"
    echo
    
    check_dependencies
    create_output_dir
    
    # Convert individual files
    if [ -d "$DOCS_DIR" ]; then
        print_info "Converting individual documentation files..."
        
        for md_file in "$DOCS_DIR"/*.md; do
            if [ -f "$md_file" ]; then
                convert_md_to_pdf "$md_file"
            fi
        done
    else
        print_error "Documentation directory not found: $DOCS_DIR"
        exit 1
    fi
    
    # Create combined PDF
    create_combined_pdf
    
    echo
    echo "========================================"
    echo "Conversion Complete!"
    echo "========================================"
    echo "PDF files created in: $OUTPUT_DIR"
    echo
    
    # List created PDFs
    if [ -d "$OUTPUT_DIR" ]; then
        echo "Generated PDFs:"
        ls -la "$OUTPUT_DIR"/*.pdf 2>/dev/null || echo "No PDF files found"
    fi
    
    print_success "Documentation conversion completed!"
}

# Run main function
main "$@"