#!/bin/bash
echo "Building Pelita Electrical Raya..."
npm run build 2>/dev/null || echo "Build script not found"
echo "Build completed"
