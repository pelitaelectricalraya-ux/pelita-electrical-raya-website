// Mobile Navigation
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    });
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Contact Form Handler
const contactForm = document.getElementById('contactForm');
const successModal = document.getElementById('successModal');
const closeModal = document.querySelector('.close');

contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(contactForm);
    const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        message: formData.get('message')
    };
    
    try {
        const response = await fetch('/api/contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            successModal.style.display = 'block';
            contactForm.reset();
        } else {
            alert('Maaf, terjadi kesalahan. Silakan coba lagi.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Maaf, terjadi kesalahan. Silakan coba lagi.');
    }
});

// Close modal
closeModal.addEventListener('click', () => {
    successModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === successModal) {
        successModal.style.display = 'none';
    }
});

// Load Projects
async function loadProjects() {
    const projectsGrid = document.getElementById('projectsGrid');
    
    try {
        const response = await fetch('/api/projects');
        const projects = await response.json();
        
        projectsGrid.innerHTML = projects.map(project => `
            <div class="project-card">
                <div class="project-image">
                    <i class="fas fa-bolt"></i>
                </div>
                <div class="project-content">
                    <h3>${project.title}</h3>
                    <p>${project.description}</p>
                    <div class="project-meta">
                        <span><i class="fas fa-calendar"></i> ${project.year}</span>
                        <span><i class="fas fa-check-circle"></i> Selesai</span>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading projects:', error);
        // Fallback projects
        projectsGrid.innerHTML = `
            <div class="project-card">
                <div class="project-image">
                    <i class="fas fa-building"></i>
                </div>
                <div class="project-content">
                    <h3>Instalasi Listrik Gedung Kantor</h3>
                    <p>Instalasi lengkap sistem listrik untuk gedung perkantoran 5 lantai dengan kapasitas 500kVA.</p>
                    <div class="project-meta">
                        <span><i class="fas fa-calendar"></i> 2024</span>
                        <span><i class="fas fa-check-circle"></i> Selesai</span>
                    </div>
                </div>
            </div>
            <div class="project-card">
                <div class="project-image">
                    <i class="fas fa-industry"></i>
                </div>
                <div class="project-content">
                    <h3>Maintenance Pabrik Manufaktur</h3>
                    <p>Kontrak maintenance tahunan untuk sistem listrik pabrik dengan preventive maintenance setiap bulan.</p>
                    <div class="project-meta">
                        <span><i class="fas fa-calendar"></i> 2024</span>
                        <span><i class="fas fa-check-circle"></i> Selesai</span>
                    </div>
                </div>
            </div>
            <div class="project-card">
                <div class="project-image">
                    <i class="fas fa-warehouse"></i>
                </div>
                <div class="project-content">
                    <h3>Audit Energi Gudang Logistik</h3>
                    <p>Audit konsumsi energi dan implementasi sistem lighting hemat energi untuk gudang seluas 10,000m².</p>
                    <div class="project-meta">
                        <span><i class="fas fa-calendar"></i> 2023</span>
                        <span><i class="fas fa-check-circle"></i> Selesai</span>
                    </div>
                </div>
            </div>
        `;
    }
}

// Initialize projects on page load
document.addEventListener('DOMContentLoaded', loadProjects);

// Header scroll effect
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.background = 'rgba(0, 42, 96, 0.95)';
        header.style.backdropFilter = 'blur(10px)';
    } else {
        header.style.background = 'linear-gradient(135deg, #002a60 0%, #004aad 100%)';
        header.style.backdropFilter = 'none';
    }
});

// Add animation on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const animateElements = document.querySelectorAll('.service-card, .project-card, .feature-card, .stat-item, .contact-card');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});