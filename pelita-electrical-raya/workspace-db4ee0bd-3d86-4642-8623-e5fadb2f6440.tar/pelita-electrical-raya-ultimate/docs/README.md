# Pelita Electrical Raya - Ultimate Package

## 🇮🇩 Bahasa Indonesia

### Deskripsi
Pelita Electrical Raya Ultimate adalah paket lengkap untuk menjalankan website portofolio perusahaan listrik yang mencakup frontend modern, backend API, admin panel, email server, proxy server, dan database dengan pengaturan mudah.

### Fitur Utama
- ✅ **Website Portofolio Modern** - Desain responsif dengan animasi dan interaksi
- ✅ **Admin Panel Lengkap** - Manajemen proyek, kontak, dan konten
- ✅ **Backend API** - Node.js dan Flask backend options
- ✅ **Database** - SQLite dengan auto-backup
- ✅ **Email Server** - Mock SMTP untuk testing + Mailcow setup
- ✅ **Proxy & DNS** - Nginx, Caddy, dan DNS lokal
- ✅ **SSL/TLS** - Otomatis dengan Let's Encrypt
- ✅ **Multi-Platform** - Linux, Windows, macOS support
- ✅ **Docker Ready** - Containerization support

### Informasi Perusahaan
- **Nama**: Pelita Electrical Raya
- **Slogan**: Solusi Listrik Andal dan Inovatif
- **Alamat**: Jalan Masjid Nurul Huda 33 RT.1/RW.1, Cengkareng Timur, Cengkareng, Jakarta Barat, DKI Jakarta 11730A
- **Telepon**: +62 813 8069 0076
- **WhatsApp**: +62 813 8069 0076
- **SMS**: +62 813 8069 0076
- **Layanan 24 Jam**: +62 813 8069 0076
- **Email**: pelitaelectricalraya@gmail.com
- **Support**: support@pelitaelectricalraya.tk
- **Maintenance**: maintenance@pelitaelectricalraya.tk
- **Info**: info@pelitaelectricalraya.tk

### Quick Start

#### Linux/macOS
```bash
# Clone atau extract package
cd pelita-electrical-raya-ultimate

# Jalankan setup script
./scripts/setup.sh

# Akses website
# http://pelitaelectricalraya
```

#### Windows
```cmd
# Extract package
cd pelita-electrical-raya-ultimate

# Jalankan setup script
scripts\setup.bat

# Akses website
# http://pelitaelectricalraya
```

### Login Admin
- **URL**: http://pelitaelectricalraya/admin
- **Username**: admin
- **Password**: Administrator123#

⚠️ **PENTING**: Ubah password default segera setelah login!

### Struktur Proyek
```
pelita-electrical-raya-ultimate/
├── backend-node/          # Node.js backend
├── backend-flask/         # Python Flask backend
├── frontend/              # Website frontend
├── admin_build/           # Admin panel
├── config/                # Konfigurasi server
├── databases/             # Database files
├── mailserver/            # Email server
├── scripts/               # Setup dan utility scripts
├── docs/                  # Dokumentasi
├── .env.example           # Template environment
└── README.md              # File ini
```

### Dokumentasi Lengkap
- [Installation Guide](INSTALLATION_GUIDE.md) - Panduan instalasi detail
- [VPS Deploy Guide](VPS_DEPLOY_GUIDE.md) - Deploy ke VPS
- [Email Server Setup](EMAIL_SERVER_SETUP.md) - Konfigurasi email
- [Security Best Practices](SECURITY_BEST_PRACTICES.md) - Keamanan
- [Backup & Restore](BACKUP_AND_RESTORE.md) - Backup dan recovery

### Dukungan Teknis
Untuk bantuan teknis, hubungi:
- 📞 +62 813 8069 0076
- 📧 pelitaelectricalraya@gmail.com
- 💬 WhatsApp: +62 813 8069 0076

---

## 🇬🇧 English

### Description
Pelita Electrical Raya Ultimate is a complete package for running an electrical company portfolio website, including modern frontend, backend API, admin panel, email server, proxy server, and database with easy setup.

### Key Features
- ✅ **Modern Portfolio Website** - Responsive design with animations and interactions
- ✅ **Complete Admin Panel** - Project, contact, and content management
- ✅ **Backend API** - Node.js and Flask backend options
- ✅ **Database** - SQLite with auto-backup
- ✅ **Email Server** - Mock SMTP for testing + Mailcow setup
- ✅ **Proxy & DNS** - Nginx, Caddy, and local DNS
- ✅ **SSL/TLS** - Automatic with Let's Encrypt
- ✅ **Multi-Platform** - Linux, Windows, macOS support
- ✅ **Docker Ready** - Containerization support

### Company Information
- **Name**: Pelita Electrical Raya
- **Slogan**: Reliable and Innovative Electrical Solutions
- **Address**: Jalan Masjid Nurul Huda 33 RT.1/RW.1, Cengkareng Timur, Cengkareng, Jakarta Barat, DKI Jakarta 11730A
- **Phone**: +62 813 8069 0076
- **WhatsApp**: +62 813 8069 0076
- **SMS**: +62 813 8069 0076
- **24/7 Service**: +62 813 8069 0076
- **Email**: pelitaelectricalraya@gmail.com
- **Support**: support@pelitaelectricalraya.tk
- **Maintenance**: maintenance@pelitaelectricalraya.tk
- **Info**: info@pelitaelectricalraya.tk

### Quick Start

#### Linux/macOS
```bash
# Clone or extract package
cd pelita-electrical-raya-ultimate

# Run setup script
./scripts/setup.sh

# Access website
# http://pelitaelectricalraya
```

#### Windows
```cmd
# Extract package
cd pelita-electrical-raya-ultimate

# Run setup script
scripts\setup.bat

# Access website
# http://pelitaelectricalraya
```

### Admin Login
- **URL**: http://pelitaelectricalraya/admin
- **Username**: admin
- **Password**: Administrator123#

⚠️ **IMPORTANT**: Change the default password immediately after login!

### Project Structure
```
pelita-electrical-raya-ultimate/
├── backend-node/          # Node.js backend
├── backend-flask/         # Python Flask backend
├── frontend/              # Website frontend
├── admin_build/           # Admin panel
├── config/                # Server configuration
├── databases/             # Database files
├── mailserver/            # Email server
├── scripts/               # Setup and utility scripts
├── docs/                  # Documentation
├── .env.example           # Environment template
└── README.md              # This file
```

### Complete Documentation
- [Installation Guide](INSTALLATION_GUIDE.md) - Detailed installation guide
- [VPS Deploy Guide](VPS_DEPLOY_GUIDE.md) - Deploy to VPS
- [Email Server Setup](EMAIL_SERVER_SETUP.md) - Email configuration
- [Security Best Practices](SECURITY_BEST_PRACTICES.md) - Security
- [Backup & Restore](BACKUP_AND_RESTORE.md) - Backup and recovery

### Technical Support
For technical support, contact:
- 📞 +62 813 8069 0076
- 📧 pelitaelectricalraya@gmail.com
- 💬 WhatsApp: +62 813 8069 0076

---

## 🚀 Quick Deployment Commands

### Development Mode
```bash
# Node.js Backend
cd backend-node && npm install && node server.js

# Python Backend (alternative)
cd backend-flask && pip install -r requirements.txt && python app.py

# Mock SMTP Server
cd mailserver && node mock_smtp.js
```

### Production Mode
```bash
# Using setup script (recommended)
./scripts/setup.sh

# Manual start
cd backend-node && NODE_ENV=production node server.js
```

### Backup
```bash
# Create backup
./scripts/backup.sh

# Convert docs to PDF
./scripts/convert_docs_to_pdf.sh
```

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Contact

Pelita Electrical Raya  
📞 +62 813 8069 0076  
📧 pelitaelectricalraya@gmail.com  
🌐 www.pelitaelectricalraya.tk

---

*Last updated: $(date)*