/*
  Mock SMTP Server for Pelita Electrical Raya
  This server simulates SMTP functionality for local testing
  Usage: node mock_smtp.js
*/

import SMTPServer from "smtp-server";

const server = new SMTPServer.SMTPServer({
  name: "pelitaelectricalraya.tk",
  banner: "Pelita Electrical Raya Mock SMTP Server",
  authOptional: true,
  disabledCommands: ["STARTTLS"],
  
  // Handle incoming data
  onData(stream, session, callback) {
    let messageData = "";
    let headers = {};
    let body = "";
    let readingHeaders = true;
    
    stream.on("data", (chunk) => {
      const data = chunk.toString();
      messageData += data;
      
      if (readingHeaders) {
        if (data.includes("\r\n\r\n") || data.includes("\n\n")) {
          readingHeaders = false;
          const parts = messageData.split(/\r\n\r\n|\n\n/);
          headers = this.parseHeaders(parts[0]);
          body = parts.slice(1).join("\r\n\r\n");
        }
      } else {
        body += data;
      }
    });
    
    stream.on("end", () => {
      console.log("\n" + "=".repeat(50));
      console.log("📧 EMAIL RECEIVED");
      console.log("=".repeat(50));
      console.log("From:", headers.from || "Unknown");
      console.log("To:", headers.to || "Unknown");
      console.log("Subject:", headers.subject || "No Subject");
      console.log("Date:", new Date().toISOString());
      console.log("\nHeaders:");
      Object.entries(headers).forEach(([key, value]) => {
        console.log(`  ${key}: ${value}`);
      });
      console.log("\nBody:");
      console.log(body.substring(0, 500) + (body.length > 500 ? "..." : ""));
      console.log("=".repeat(50) + "\n");
      
      // Store email in database (optional)
      this.storeEmail(headers, body);
      
      callback(null, "Message accepted");
    });
  },
  
  parseHeaders(headerString) {
    const headers = {};
    const lines = headerString.split(/\r?\n/);
    
    for (const line of lines) {
      const colonIndex = line.indexOf(':');
      if (colonIndex > 0) {
        const key = line.substring(0, colonIndex).trim().toLowerCase();
        const value = line.substring(colonIndex + 1).trim();
        headers[key] = value;
      }
    }
    
    return headers;
  },
  
  async storeEmail(headers, body) {
    try {
      // This would normally store in a database
      // For now, just log to a file
      const fs = await import('fs');
      const emailData = {
        id: Date.now(),
        from: headers.from,
        to: headers.to,
        subject: headers.subject,
        body: body,
        received_at: new Date().toISOString(),
        headers: headers
      };
      
      const logFile = './mailserver/emails.log';
      await fs.promises.appendFile(logFile, JSON.stringify(emailData) + '\n');
      console.log("Email logged to:", logFile);
    } catch (error) {
      console.error("Error storing email:", error);
    }
  }
});

// Handle server errors
server.on("error", (err) => {
  console.error("SMTP Server Error:", err);
});

server.on("connect", (session) => {
  console.log(`New connection from: ${session.remoteAddress}`);
});

// Start server
const PORT = 1025;
server.listen(PORT, () => {
  console.log(`🚀 Mock SMTP Server running on port ${PORT}`);
  console.log(`📧 Ready to receive emails for Pelita Electrical Raya`);
  console.log(`🔗 Configure your email client to use localhost:${PORT}`);
  console.log(`⚠️  This is a development server only - emails are not delivered externally`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down SMTP server...');
  server.close(() => {
    console.log('✅ SMTP server stopped');
    process.exit(0);
  });
});

export default server;