import express from "express";
import cors from "cors";
import session from "express-session";
import bcrypt from "bcrypt";
import sqlite3 from "sqlite3";
import { open } from "sqlite";
import path from "path";
import { fileURLToPath } from "url";
import nodemailer from "nodemailer";
import multer from "multer";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());
app.use(cors());
app.use(session({
  secret: process.env.SESSION_SECRET || "pelita_secret_change",
  resave: false,
  saveUninitialized: false,
  cookie: { secure: (process.env.SESSION_SECURE === "true") }
}));

// Static files
app.use(express.static(path.join(__dirname, "..", "frontend")));
app.use("/admin", express.static(path.join(__dirname, "..", "admin_build")));

// Database setup
const dbPath = path.join(__dirname, "db", "pelita.sqlite");
await import('fs').then(fs=>fs.promises.mkdir(path.join(__dirname, "db"), { recursive: true }));
const db = await open({ filename: dbPath, driver: sqlite3.Database });

// Initialize tables
await db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, 
    username TEXT UNIQUE, 
    password TEXT,
    email TEXT,
    role TEXT DEFAULT 'admin'
  );
  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT, 
    title TEXT, 
    description TEXT, 
    year INTEGER,
    category TEXT,
    image TEXT,
    status TEXT DEFAULT 'completed'
  );
  CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, 
    name TEXT, 
    email TEXT, 
    phone TEXT,
    message TEXT, 
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    icon TEXT,
    featured INTEGER DEFAULT 0
  );
`);

// Create default admin if not exists
const adminUser = process.env.ADMIN_USER || "admin";
const adminPass = process.env.ADMIN_PASSWORD || "Administrator123#";
const row = await db.get("SELECT id FROM users WHERE username = ?", [adminUser]);
if (!row) {
  const hash = await bcrypt.hash(adminPass, 10);
  await db.run("INSERT INTO users (username,password,email,role) VALUES (?,?,?,?)", 
    [adminUser, hash, "admin@pelitaelectricalraya.tk", "admin"]);
  console.log("Default admin created:", adminUser);
}

// Seed sample data
const projectCount = await db.get("SELECT COUNT(*) as count FROM projects");
if (projectCount.count === 0) {
  await db.run(`
    INSERT INTO projects (title, description, year, category, status) VALUES 
    ('Instalasi Listrik Gedung Kantor', 'Instalasi lengkap sistem listrik untuk gedung perkantoran 5 lantai dengan kapasitas 500kVA.', 2024, 'installation', 'completed'),
    ('Maintenance Pabrik Manufaktur', 'Kontrak maintenance tahunan untuk sistem listrik pabrik dengan preventive maintenance setiap bulan.', 2024, 'maintenance', 'ongoing'),
    ('Audit Energi Gudang Logistik', 'Audit konsumsi energi dan implementasi sistem lighting hemat energi untuk gudang seluas 10,000m².', 2023, 'audit', 'completed'),
    ('Panel Listrik Distribusi', 'Upgrade panel distribusi utama dengan sistem proteksi modern untuk kompleks industri.', 2024, 'panel', 'completed'),
    ('Instalasi Lighting Commercial', 'Desain dan instalasi sistem pencahayaan LED untuk mall dengan sistem kontrol otomatis.', 2023, 'lighting', 'completed'),
    ('Grounding System', 'Instalasi sistem grounding dan proteksi petir untuk tower telekomunikasi.', 2024, 'grounding', 'completed')
  `);
}

const serviceCount = await db.get("SELECT COUNT(*) as count FROM services");
if (serviceCount.count === 0) {
  await db.run(`
    INSERT INTO services (title, description, icon, featured) VALUES 
    ('Instalasi Listrik', 'Instalasi listrik baru untuk rumah, kantor, dan industri dengan standar keamanan tertinggi.', 'fas fa-plug', 1),
    ('Maintenance', 'Perawatan berkala dan perbaikan sistem listrik untuk mencegah masalah sebelum terjadi.', 'fas fa-tools', 1),
    ('Audit Energi', 'Analisis konsumsi energi dan rekomendasi efisiensi untuk menghemat biaya operasional.', 'fas fa-chart-line', 1),
    ('Panel Listrik', 'Desain, instalasi, dan upgrade panel listrik distribusi dan kontrol.', 'fas fa-microchip', 0),
    ('Lighting Design', 'Desain pencahayaan efisien dan estetis untuk berbagai aplikasi.', 'fas fa-lightbulb', 0),
    ('Grounding System', 'Instalasi sistem grounding dan proteksi petir untuk keselamatan maksimal.', 'fas fa-bolt', 0)
  `);
}

// Email configuration
const transporter = nodemailer.createTransporter({
  host: process.env.MAIL_HOST || 'localhost',
  port: parseInt(process.env.MAIL_PORT) || 1025,
  secure: false,
  auth: {
    user: process.env.MAIL_USER || '',
    pass: process.env.MAIL_PASS || ''
  }
});

// API Routes

// Status endpoint
app.get("/api/status", (_,res)=> res.json({status:"ok", service:"pelita-node-backend", timestamp: new Date().toISOString()}));

// Contact form submission
app.post("/api/contact", async (req,res)=>{
  try {
    const { name, email, phone, message } = req.body;
    
    // Save to database
    await db.run("INSERT INTO contacts (name,email,phone,message) VALUES (?,?,?,?)", 
      [name, email, phone, message]);
    
    // Send email notification
    const mailOptions = {
      from: process.env.MAIL_FROM || 'noreply@pelitaelectricalraya.tk',
      to: 'pelitaelectricalraya@gmail.com',
      subject: `Kontak Baru dari ${name}`,
      html: `
        <h2>Pesan Kontak Baru</h2>
        <p><strong>Nama:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Telepon:</strong> ${phone || 'Tidak disediakan'}</p>
        <p><strong>Pesan:</strong></p>
        <p>${message}</p>
        <hr>
        <p><small>Pesan dikirim pada: ${new Date().toLocaleString('id-ID')}</small></p>
      `
    };
    
    try {
      await transporter.sendMail(mailOptions);
    } catch (emailError) {
      console.error('Failed to send email:', emailError);
      // Continue even if email fails
    }
    
    res.json({success: true, message: "Pesan berhasil dikirim"});
  } catch (error) {
    console.error('Contact form error:', error);
    res.status(500).json({success: false, message: "Terjadi kesalahan server"});
  }
});

// Get projects
app.get("/api/projects", async (req,res)=>{
  try {
    const projects = await db.all("SELECT * FROM projects ORDER BY year DESC");
    res.json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({error: "Failed to fetch projects"});
  }
});

// Get services
app.get("/api/services", async (req,res)=>{
  try {
    const services = await db.all("SELECT * FROM services ORDER BY featured DESC, title");
    res.json(services);
  } catch (error) {
    console.error('Error fetching services:', error);
    res.status(500).json({error: "Failed to fetch services"});
  }
});

// Get contacts (admin only)
app.get("/api/contacts", async (req,res)=>{
  try {
    const contacts = await db.all("SELECT * FROM contacts ORDER BY created_at DESC");
    res.json(contacts);
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({error: "Failed to fetch contacts"});
  }
});

// Auth endpoints
app.post("/api/auth/login", async (req,res)=>{
  try {
    const { username, password } = req.body;
    const u = await db.get("SELECT id,username,password,email,role FROM users WHERE username = ?", [username]);
    if(!u) return res.status(401).json({error:"Invalid credentials"});
    
    const ok = await bcrypt.compare(password, u.password);
    if(!ok) return res.status(401).json({error:"Invalid credentials"});
    
    req.session.user = { 
      id: u.id, 
      username: u.username, 
      email: u.email,
      role: u.role
    };
    res.json({success:true, user: req.session.user});
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({error:"Login failed"});
  }
});

app.post("/api/auth/logout", (req,res)=>{
  req.session.destroy(()=>res.json({success:true}));
});

app.get("/api/auth/me", (req,res)=>{
  if(req.session && req.session.user) return res.json({user:req.session.user});
  res.status(401).json({error:"unauthorized"});
});

// Admin middleware
function ensureAuth(req,res,next){
  if(req.session && req.session.user) return next();
  return res.status(401).json({error:"unauthorized"});
}

// Admin CRUD operations for projects
app.get("/api/admin/projects", ensureAuth, async (req,res)=>{
  try {
    const projects = await db.all("SELECT * FROM projects ORDER BY year DESC");
    res.json(projects);
  } catch (error) {
    console.error('Error fetching admin projects:', error);
    res.status(500).json({error:"Failed to fetch projects"});
  }
});

app.post("/api/admin/projects", ensureAuth, async (req,res)=>{
  try {
    const { title, description, year, category, status } = req.body;
    const r = await db.run("INSERT INTO projects (title,description,year,category,status) VALUES (?,?,?,?,?)", 
      [title, description, year, category, status]);
    res.json({id:r.lastID, success:true});
  } catch (error) {
    console.error('Error creating project:', error);
    res.status(500).json({error:"Failed to create project"});
  }
});

app.put("/api/admin/projects/:id", ensureAuth, async (req,res)=>{
  try {
    const { id } = req.params;
    const { title, description, year, category, status } = req.body;
    await db.run("UPDATE projects SET title=?,description=?,year=?,category=?,status=? WHERE id=?", 
      [title, description, year, category, status, id]);
    res.json({success:true});
  } catch (error) {
    console.error('Error updating project:', error);
    res.status(500).json({error:"Failed to update project"});
  }
});

app.delete("/api/admin/projects/:id", ensureAuth, async (req,res)=>{
  try {
    const { id } = req.params;
    await db.run("DELETE FROM projects WHERE id=?", [id]);
    res.json({success:true});
  } catch (error) {
    console.error('Error deleting project:', error);
    res.status(500).json({error:"Failed to delete project"});
  }
});

// Admin CRUD for services
app.get("/api/admin/services", ensureAuth, async (req,res)=>{
  try {
    const services = await db.all("SELECT * FROM services ORDER BY featured DESC, title");
    res.json(services);
  } catch (error) {
    console.error('Error fetching admin services:', error);
    res.status(500).json({error:"Failed to fetch services"});
  }
});

app.post("/api/admin/services", ensureAuth, async (req,res)=>{
  try {
    const { title, description, icon, featured } = req.body;
    const r = await db.run("INSERT INTO services (title,description,icon,featured) VALUES (?,?,?,?)", 
      [title, description, icon, featured ? 1 : 0]);
    res.json({id:r.lastID, success:true});
  } catch (error) {
    console.error('Error creating service:', error);
    res.status(500).json({error:"Failed to create service"});
  }
});

app.put("/api/admin/services/:id", ensureAuth, async (req,res)=>{
  try {
    const { id } = req.params;
    const { title, description, icon, featured } = req.body;
    await db.run("UPDATE services SET title=?,description=?,icon=?,featured=? WHERE id=?", 
      [title, description, icon, featured ? 1 : 0, id]);
    res.json({success:true});
  } catch (error) {
    console.error('Error updating service:', error);
    res.status(500).json({error:"Failed to update service"});
  }
});

app.delete("/api/admin/services/:id", ensureAuth, async (req,res)=>{
  try {
    const { id } = req.params;
    await db.run("DELETE FROM services WHERE id=?", [id]);
    res.json({success:true});
  } catch (error) {
    console.error('Error deleting service:', error);
    res.status(500).json({error:"Failed to delete service"});
  }
});

// Admin stats
app.get("/api/admin/stats", ensureAuth, async (req,res)=>{
  try {
    const projects = await db.get("SELECT COUNT(*) as count FROM projects");
    const contacts = await db.get("SELECT COUNT(*) as count FROM contacts");
    const recentContacts = await db.all("SELECT * FROM contacts ORDER BY created_at DESC LIMIT 5");
    
    res.json({
      projects: projects.count,
      contacts: contacts.count,
      recentContacts
    });
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    res.status(500).json({error:"Failed to fetch stats"});
  }
});

// Serve frontend for all other routes
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "frontend", "index.html"));
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`🚀 Pelita Electrical Raya Backend running on port ${PORT}`);
  console.log(`📧 Email service: ${process.env.MAIL_HOST}:${process.env.MAIL_PORT}`);
  console.log(`🗄️  Database: ${dbPath}`);
  console.log(`🌐 Frontend: http://localhost:${PORT}`);
  console.log(`🔧 Admin: http://localhost:${PORT}/admin`);
});