from flask import Flask, request, jsonify, session, send_from_directory
from flask_cors import CORS
from flask_session import Session
import sqlite3, os, hashlib, bcrypt
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

app = Flask(__name__, static_folder='../frontend', static_url_path='/')
CORS(app)
app.config['SESSION_TYPE'] = 'filesystem'
app.secret_key = os.environ.get('SESSION_SECRET','please_change_this_to_a_random_secret')
Session(app)

DB_PATH = os.path.join(os.path.dirname(__file__), 'db', 'pelita.sqlite')
os.makedirs(os.path.join(os.path.dirname(__file__), 'db'), exist_ok=True)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# Initialize database
def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.executescript('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        username TEXT UNIQUE, 
        password TEXT,
        email TEXT,
        role TEXT DEFAULT 'admin'
    );
    CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        title TEXT, 
        description TEXT, 
        year INTEGER,
        category TEXT,
        image TEXT,
        status TEXT DEFAULT 'completed'
    );
    CREATE TABLE IF NOT EXISTS contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT, 
        email TEXT, 
        phone TEXT,
        message TEXT, 
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        icon TEXT,
        featured INTEGER DEFAULT 0
    );
    ''')
    conn.commit()
    
    # Create default admin
    admin_user = os.environ.get('ADMIN_USER','admin')
    admin_pass = os.environ.get('ADMIN_PASSWORD','Administrator123#')
    cur = conn.cursor()
    cur.execute("SELECT id FROM users WHERE username=?", (admin_user,))
    if not cur.fetchone():
        hashed = bcrypt.hashpw(admin_pass.encode('utf-8'), bcrypt.gensalt())
        cur.execute("INSERT INTO users (username,password,email,role) VALUES (?,?,?,?)", 
                   (admin_user, hashed, "admin@pelitaelectricalraya.tk", "admin"))
        conn.commit()
        print(f"Default admin created: {admin_user}")
    
    # Seed sample data
    cur.execute("SELECT COUNT(*) as count FROM projects")
    if cur.fetchone()['count'] == 0:
        projects = [
            ('Instalasi Listrik Gedung Kantor', 'Instalasi lengkap sistem listrik untuk gedung perkantoran 5 lantai dengan kapasitas 500kVA.', 2024, 'installation', 'completed'),
            ('Maintenance Pabrik Manufaktur', 'Kontrak maintenance tahunan untuk sistem listrik pabrik dengan preventive maintenance setiap bulan.', 2024, 'maintenance', 'ongoing'),
            ('Audit Energi Gudang Logistik', 'Audit konsumsi energi dan implementasi sistem lighting hemat energi untuk gudang seluas 10,000m².', 2023, 'audit', 'completed'),
            ('Panel Listrik Distribusi', 'Upgrade panel distribusi utama dengan sistem proteksi modern untuk kompleks industri.', 2024, 'panel', 'completed'),
            ('Instalasi Lighting Commercial', 'Desain dan instalasi sistem pencahayaan LED untuk mall dengan sistem kontrol otomatis.', 2023, 'lighting', 'completed'),
            ('Grounding System', 'Instalasi sistem grounding dan proteksi petir untuk tower telekomunikasi.', 2024, 'grounding', 'completed')
        ]
        cur.executemany("INSERT INTO projects (title,description,year,category,status) VALUES (?,?,?,?,?)", projects)
        conn.commit()
    
    cur.execute("SELECT COUNT(*) as count FROM services")
    if cur.fetchone()['count'] == 0:
        services = [
            ('Instalasi Listrik', 'Instalasi listrik baru untuk rumah, kantor, dan industri dengan standar keamanan tertinggi.', 'fas fa-plug', 1),
            ('Maintenance', 'Perawatan berkala dan perbaikan sistem listrik untuk mencegah masalah sebelum terjadi.', 'fas fa-tools', 1),
            ('Audit Energi', 'Analisis konsumsi energi dan rekomendasi efisiensi untuk menghemat biaya operasional.', 'fas fa-chart-line', 1),
            ('Panel Listrik', 'Desain, instalasi, dan upgrade panel listrik distribusi dan kontrol.', 'fas fa-microchip', 0),
            ('Lighting Design', 'Desain pencahayaan efisien dan estetis untuk berbagai aplikasi.', 'fas fa-lightbulb', 0),
            ('Grounding System', 'Instalasi sistem grounding dan proteksi petir untuk keselamatan maksimal.', 'fas fa-bolt', 0)
        ]
        cur.executemany("INSERT INTO services (title,description,icon,featured) VALUES (?,?,?,?)", services)
        conn.commit()
    
    conn.close()

# Initialize database on startup
init_db()

@app.route('/api/status')
def status():
    return jsonify({
        'status': 'ok', 
        'service': 'pelita-flask-backend',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/contact', methods=['POST'])
def contact():
    try:
        data = request.get_json()
        conn = get_db()
        cur = conn.cursor()
        cur.execute("INSERT INTO contacts (name,email,phone,message) VALUES (?,?,?,?)", 
                   (data.get('name'), data.get('email'), data.get('phone'), data.get('message')))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': 'Pesan berhasil dikirim'})
    except Exception as e:
        print(f'Contact form error: {e}')
        return jsonify({'success': False, 'message': 'Terjadi kesalahan server'}), 500

@app.route('/api/projects')
def get_projects():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM projects ORDER BY year DESC")
        projects = [dict(row) for row in cur.fetchall()]
        conn.close()
        return jsonify(projects)
    except Exception as e:
        print(f'Error fetching projects: {e}')
        return jsonify({'error': 'Failed to fetch projects'}), 500

@app.route('/api/services')
def get_services():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM services ORDER BY featured DESC, title")
        services = [dict(row) for row in cur.fetchall()]
        conn.close()
        return jsonify(services)
    except Exception as e:
        print(f'Error fetching services: {e}')
        return jsonify({'error': 'Failed to fetch services'}), 500

@app.route('/api/contacts')
def get_contacts():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM contacts ORDER BY created_at DESC")
        contacts = [dict(row) for row in cur.fetchall()]
        conn.close()
        return jsonify(contacts)
    except Exception as e:
        print(f'Error fetching contacts: {e}')
        return jsonify({'error': 'Failed to fetch contacts'}), 500

# Auth endpoints
@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id,username,password,email,role FROM users WHERE username=?", (username,))
        user = cur.fetchone()
        conn.close()
        
        if not user or not bcrypt.checkpw(password.encode('utf-8'), user['password']):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        session['user'] = {
            'id': user['id'],
            'username': user['username'],
            'email': user['email'],
            'role': user['role']
        }
        return jsonify({'success': True, 'user': session['user']})
    except Exception as e:
        print(f'Login error: {e}')
        return jsonify({'error': 'Login failed'}), 500

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/auth/me')
def me():
    if 'user' in session:
        return jsonify({'user': session['user']})
    return jsonify({'error': 'unauthorized'}), 401

# Admin middleware
def require_auth(f):
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return jsonify({'error': 'unauthorized'}), 401
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# Admin endpoints
@app.route('/api/admin/projects')
@require_auth
def admin_get_projects():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM projects ORDER BY year DESC")
        projects = [dict(row) for row in cur.fetchall()]
        conn.close()
        return jsonify(projects)
    except Exception as e:
        print(f'Error fetching admin projects: {e}')
        return jsonify({'error': 'Failed to fetch projects'}), 500

@app.route('/api/admin/projects', methods=['POST'])
@require_auth
def admin_create_project():
    try:
        data = request.get_json()
        conn = get_db()
        cur = conn.cursor()
        cur.execute("INSERT INTO projects (title,description,year,category,status) VALUES (?,?,?,?,?)",
                   (data.get('title'), data.get('description'), data.get('year'), 
                    data.get('category'), data.get('status', 'completed')))
        conn.commit()
        project_id = cur.lastrowid
        conn.close()
        return jsonify({'id': project_id, 'success': True})
    except Exception as e:
        print(f'Error creating project: {e}')
        return jsonify({'error': 'Failed to create project'}), 500

@app.route('/api/admin/projects/<int:project_id>', methods=['PUT'])
@require_auth
def admin_update_project(project_id):
    try:
        data = request.get_json()
        conn = get_db()
        cur = conn.cursor()
        cur.execute("UPDATE projects SET title=?,description=?,year=?,category=?,status=? WHERE id=?",
                   (data.get('title'), data.get('description'), data.get('year'), 
                    data.get('category'), data.get('status'), project_id))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        print(f'Error updating project: {e}')
        return jsonify({'error': 'Failed to update project'}), 500

@app.route('/api/admin/projects/<int:project_id>', methods=['DELETE'])
@require_auth
def admin_delete_project(project_id):
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("DELETE FROM projects WHERE id=?", (project_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        print(f'Error deleting project: {e}')
        return jsonify({'error': 'Failed to delete project'}), 500

@app.route('/api/admin/stats')
@require_auth
def admin_stats():
    try:
        conn = get_db()
        cur = conn.cursor()
        
        cur.execute("SELECT COUNT(*) as count FROM projects")
        projects_count = cur.fetchone()['count']
        
        cur.execute("SELECT COUNT(*) as count FROM contacts")
        contacts_count = cur.fetchone()['count']
        
        cur.execute("SELECT * FROM contacts ORDER BY created_at DESC LIMIT 5")
        recent_contacts = [dict(row) for row in cur.fetchall()]
        
        conn.close()
        return jsonify({
            'projects': projects_count,
            'contacts': contacts_count,
            'recentContacts': recent_contacts
        })
    except Exception as e:
        print(f'Error fetching admin stats: {e}')
        return jsonify({'error': 'Failed to fetch stats'}), 500

# Serve frontend
@app.route('/')
def index():
    return send_from_directory('../frontend', 'index.html')

@app.route('/admin')
def admin():
    return send_from_directory('../admin_build', 'admin_app.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)