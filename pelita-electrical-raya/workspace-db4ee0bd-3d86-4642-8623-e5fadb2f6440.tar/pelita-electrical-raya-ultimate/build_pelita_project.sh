#!/bin/bash

# Pelita Electrical Raya - Ultimate Build Script
# This script creates the complete project package

set -e

# Configuration
PROJECT_NAME="pelita-electrical-raya-ultimate"
OUTZIP="pelita-electrical-raya-ultimate.zip"
ROOT="$(pwd)"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Main build process
main() {
    print_header "Building Pelita Electrical Raya Ultimate Package"
    
    print_info "Creating project structure..."
    
    # Create main directories
    mkdir -p "$PROJECT_NAME"/{backend-node,backend-flask,frontend/{assets,css,js},admin_build,config,databases/{backup},mailserver,scripts,docs}
    
    print_success "Directory structure created"
    
    # Copy environment files
    print_info "Creating environment files..."
    cat > "$PROJECT_NAME/.env.example" << 'ENV'
# Pelita Electrical Raya - environment template
DOMAIN=pelitaelectricalraya
ADMIN_USER=admin
ADMIN_PASSWORD=Administrator123#
DB_TYPE=sqlite,postgres
SESSION_SECRET=please_change_this_to_a_random_secret
SESSION_SECURE=false
MAIL_HOST=localhost
MAIL_PORT=1025
ENV
    
    cat > "$PROJECT_NAME/.env" << 'ENV'
# Pelita Electrical Raya - environment configuration
DOMAIN=pelitaelectricalraya
ADMIN_USER=admin
ADMIN_PASSWORD=Administrator123#
DB_TYPE=sqlite,postgres
SESSION_SECRET=pelita_electrical_raya_secret_2025_secure_key_change_me
SESSION_SECURE=false
MAIL_HOST=localhost
MAIL_PORT=1025
ENV
    
    print_success "Environment files created"
    
    # Copy all existing files
    print_info "Copying project files..."
    
    # Copy backend files
    if [ -d "backend-node" ]; then
        cp -r backend-node/* "$PROJECT_NAME/backend-node/"
        print_success "Node.js backend copied"
    fi
    
    if [ -d "backend-flask" ]; then
        cp -r backend-flask/* "$PROJECT_NAME/backend-flask/"
        print_success "Flask backend copied"
    fi
    
    # Copy frontend files
    if [ -d "frontend" ]; then
        cp -r frontend/* "$PROJECT_NAME/frontend/"
        print_success "Frontend copied"
    fi
    
    # Copy admin panel
    if [ -d "admin_build" ]; then
        cp -r admin_build/* "$PROJECT_NAME/admin_build/"
        print_success "Admin panel copied"
    fi
    
    # Copy configuration
    if [ -d "config" ]; then
        cp -r config/* "$PROJECT_NAME/config/"
        print_success "Configuration copied"
    fi
    
    # Copy mailserver
    if [ -d "mailserver" ]; then
        cp -r mailserver/* "$PROJECT_NAME/mailserver/"
        print_success "Mail server copied"
    fi
    
    # Copy scripts
    if [ -d "scripts" ]; then
        cp -r scripts/* "$PROJECT_NAME/scripts/"
        # Make scripts executable
        chmod +x "$PROJECT_NAME/scripts"/*.sh
        print_success "Scripts copied and made executable"
    fi
    
    # Copy documentation
    if [ -d "docs" ]; then
        cp -r docs/* "$PROJECT_NAME/docs/"
        print_success "Documentation copied"
    fi
    
    # Create additional documentation
    print_info "Creating additional documentation..."
    
    cat > "$PROJECT_NAME/docs/INSTALLATION_GUIDE.md" << 'DOC'
# Installation Guide - Pelita Electrical Raya

## 🇮🇩 Bahasa Indonesia

### Persyaratan Sistem
- OS: Linux (Ubuntu 20.04+), Windows 10+, macOS 10.15+
- Node.js 16+ atau Python 3.8+
- SQLite 3
- 2GB RAM minimum
- 5GB disk space

### Instalasi Linux/macOS
```bash
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
./scripts/setup.sh

# 3. Access website
open http://pelitaelectricalraya
```

### Instalasi Windows
```cmd
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
scripts\setup.bat

# 3. Access website
start http://pelitaelectricalraya
```

### Konfigurasi Lanjutan
Edit file `.env` untuk mengubah:
- DOMAIN: Domain untuk website
- ADMIN_PASSWORD: Password admin
- SESSION_SECRET: Secret key untuk session
- MAIL_HOST/PORT: Konfigurasi email server

### Troubleshooting
- Port 8080/5000 sudah digunakan: Kill process atau ubah port
- Permission denied: Gunakan sudo (Linux) atau Run as Administrator (Windows)
- Node.js tidak ditemukan: Install dari https://nodejs.org

## 🇬🇧 English

### System Requirements
- OS: Linux (Ubuntu 20.04+), Windows 10+, macOS 10.15+
- Node.js 16+ or Python 3.8+
- SQLite 3
- 2GB RAM minimum
- 5GB disk space

### Linux/macOS Installation
```bash
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
./scripts/setup.sh

# 3. Access website
open http://pelitaelectricalraya
```

### Windows Installation
```cmd
# 1. Extract package
cd pelita-electrical-raya-ultimate

# 2. Run setup script
scripts\setup.bat

# 3. Access website
start http://pelitaelectricalraya
```

### Advanced Configuration
Edit `.env` file to change:
- DOMAIN: Website domain
- ADMIN_PASSWORD: Admin password
- SESSION_SECRET: Session secret key
- MAIL_HOST/PORT: Email server configuration

### Troubleshooting
- Port 8080/5000 in use: Kill process or change port
- Permission denied: Use sudo (Linux) or Run as Administrator (Windows)
- Node.js not found: Install from https://nodejs.org
DOC
    
    print_success "Additional documentation created"
    
    # Create build script
    print_info "Creating build scripts..."
    
    cat > "$PROJECT_NAME/build.sh" << 'BUILD'
#!/bin/bash
echo "Building Pelita Electrical Raya..."
npm run build 2>/dev/null || echo "Build script not found"
echo "Build completed"
BUILD
    
    cat > "$PROJECT_NAME/build.bat" << 'BUILD'
@echo off
echo Building Pelita Electrical Raya...
npm run build 2>nul || echo Build script not found
echo Build completed
BUILD
    
    chmod +x "$PROJECT_NAME/build.sh"
    print_success "Build scripts created"
    
    # Create LICENSE file
    print_info "Creating license file..."
    cat > "$PROJECT_NAME/LICENSE" << 'LICENSE'
MIT License

Copyright (c) 2025 Pelita Electrical Raya

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
LICENSE
    
    print_success "License file created"
    
    # Create ZIP archive
    print_info "Creating ZIP archive..."
    cd "$PROJECT_NAME"
    zip -r "../$OUTZIP" . -x "*.DS_Store" "*/.DS_Store"
    cd ..
    
    # Get file size
    if command -v du &> /dev/null; then
        SIZE=$(du -h "$OUTZIP" | cut -f1)
    else
        SIZE=$(ls -lh "$OUTZIP" | awk '{print $5}')
    fi
    
    print_success "ZIP archive created: $OUTZIP ($SIZE)"
    
    # Display summary
    echo
    print_header "Build Summary"
    echo "Project: Pelita Electrical Raya Ultimate"
    echo "Output: $OUTZIP"
    echo "Size: $SIZE"
    echo "Location: $(pwd)/$OUTZIP"
    echo
    echo "Contents:"
    echo "• Frontend website (HTML/CSS/JS)"
    echo "• Admin panel (React SPA)"
    echo "• Backend API (Node.js + Flask)"
    echo "• Database (SQLite)"
    echo "• Email server (Mock SMTP)"
    echo "• Configuration files"
    echo "• Setup scripts (Linux/Windows)"
    echo "• Complete documentation"
    echo
    print_success "Build completed successfully!"
    
    echo
    print_info "Next steps:"
    echo "1. Extract $OUTZIP to your server"
    echo "2. Run ./scripts/setup.sh (Linux) or scripts\\setup.bat (Windows)"
    echo "3. Access http://pelitaelectricalraya"
    echo "4. Login to admin panel: http://pelitaelectricalraya/admin"
    echo "   Username: admin, Password: Administrator123#"
}

# Run main function
main "$@"