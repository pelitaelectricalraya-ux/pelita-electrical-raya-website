# ✅ Pelita Electrical Raya - 部署检查清单

## 🚀 部署前检查
- [ ] 已下载 `pelita-electrical-raya-ultimate.tar.gz`
- [ ] 有管理员权限（sudo/admin）
- [ ] 网络连接正常
- [ ] 防火墙允许80端口访问

## 📦 解压和准备
```bash
# 检查文件完整性
tar -tzf pelita-electrical-raya-ultimate.tar.gz | head -10

# 解压到合适位置
tar -xzf pelita-electrical-raya-ultimate.tar.gz
cd pelita-electrical-raya-ultimate
ls -la
```

## 🔧 系统要求检查
- [ ] 操作系统: Linux/Windows/macOS
- [ ] Node.js 14+ (或安装脚本会自动安装)
- [ ] Python 3.7+ (后端选项)
- [ ] 80端口未被占用

## 🏃‍♂️ 自动部署
```bash
# Linux/macOS
chmod +x install-linux.sh
./install-linux.sh

# Windows
install-windows.bat
```

## ✅ 部署后验证

### 1. 网站访问测试
- [ ] 主页: http://pelitaelectricalraya ✅
- [ ] 关于页面: http://pelitaelectricalraya/about ✅
- [ ] 服务页面: http://pelitaelectricalraya/services ✅
- [ ] 项目页面: http://pelitaelectricalraya/projects ✅
- [ ] 联系页面: http://pelitaelectricalraya/contact ✅

### 2. 管理面板测试
- [ ] 管理登录: http://pelitaelectricalraya/admin ✅
- [ ] 用户名: admin ✅
- [ ] 密码: Administrator123# ✅
- [ ] 项目管理功能 ✅
- [ ] 联系人管理功能 ✅

### 3. API 测试
- [ ] API 响应: http://pelitaelectricalraya/api/projects ✅
- [ ] 数据库连接 ✅
- [ ] CRUD 操作 ✅

### 4. 功能测试
- [ ] 联系表单提交 ✅
- [ ] 响应式设计（手机/平板）✅
- [ ] 图片加载正常 ✅
- [ ] 导航菜单工作 ✅

## 🔍 故障排除快速指南

### 无法访问网站
```bash
# 检查服务状态
sudo systemctl status nginx apache2 pelita-website

# 检查端口
sudo netstat -tulpn | grep :80

# 检查DNS
cat /etc/hosts | grep pelitaelectricalraya
```

### 管理面板无法登录
- [ ] 检查用户名密码: admin / Administrator123#
- [ ] 清除浏览器缓存
- [ ] 检查控制台错误信息

### 数据库问题
```bash
# 检查数据库文件
ls -la /var/www/pelita/backend/database.db

# 重新初始化数据库
cd /var/www/pelita/backend
npm run init-db
```

## 📊 性能优化建议
- [ ] 启用 gzip 压缩
- [ ] 配置缓存策略
- [ ] 优化图片大小
- [ ] 使用 CDN（可选）

## 🔒 安全检查
- [ ] 修改默认密码
- [ ] 配置防火墙规则
- [ ] 启用 HTTPS（生产环境）
- [ ] 定期备份数据

## 📞 技术支持
如果遇到问题：
1. 查看日志: `tail -f /var/log/pelita-website.log`
2. 检查文档: `README.md`
3. 联系支持: pelitaelectricalraya@gmail.com

## 🎉 部署完成！
恭喜！您已成功部署 Pelita Electrical Raya 完整网站系统！

---
*部署日期: ___________*  
*部署人员: ___________*  
*版本: 1.0*