#!/bin/bash
BACKUP_DIR=/backups/pelita_$(date +%F)
mkdir -p "$BACKUP_DIR"
echo "Backing up /opt/pelita to $BACKUP_DIR..."
tar czf "$BACKUP_DIR/pelita_www_$(date +%F).tar.gz" /opt/pelita || true
echo "Backup completed."