#!/bin/bash
echo "Restore example - adjust paths"
echo "tar xzf /backups/pelita_YYYY-MM-DD/pelita_www_YYYY-MM-DD.tar.gz -C /opt/pelita"