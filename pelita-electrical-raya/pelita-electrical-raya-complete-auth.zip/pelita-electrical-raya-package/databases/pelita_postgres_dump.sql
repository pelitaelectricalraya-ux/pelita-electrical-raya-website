
-- Postgres dump for pelita_db
CREATE TABLE contacts (id SERIAL PRIMARY KEY, name TEXT, email TEXT, message TEXT, created_at TIMESTAMP DEFAULT now());
CREATE TABLE projects (id SERIAL PRIMARY KEY, title TEXT, description TEXT, year INTEGER);
INSERT INTO projects (title,description,year) VALUES ('Pemasangan Panel Listrik','Instalasi panel distribusi untuk pabrik X',2024);
INSERT INTO contacts (name,email,message) VALUES ('Budi','budi@example.com','Butuh penawaran');

-- extra seed
INSERT INTO projects (title,description,year) VALUES
('Instalasi PJU Jalan Raya','Penerangan jalan umum dengan tiang dan panel kontrol',2023),('Panel Distribusi Pabrik Y','Upgrade panel dan pengaturan proteksi',2024),('Retrofit Lampu LED Gedung ABC','Konversi lampu hemat energi di gedung perkantoran',2022);

INSERT INTO contacts (name,email,message) VALUES
('Siti','siti@example.com','Minta penawaran untuk pju jalan'),('Andi','andi@example.com','Butuh maintenance mingguan'),('Rina','rina@example.com','Konsultasi audit energi');
