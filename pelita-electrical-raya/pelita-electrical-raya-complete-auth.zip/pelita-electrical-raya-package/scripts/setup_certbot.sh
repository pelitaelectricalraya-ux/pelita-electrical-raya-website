#!/bin/bash
# Example certbot setup for nginx
# Requires domain pointing to this server.
if [ -z "$1" ]; then
  echo "Usage: ./setup_certbot.sh yourdomain.tld"
  exit 1
fi
domain=$1
sudo certbot --nginx -d $domain
