#!/bin/bash
mkdir -p backups
cp databases/pelita.sqlite backups/pelita.sqlite.$(date +%Y%m%d%H%M%S)
echo "SQLite backup created in backups/"
