
Mailcow setup notes:
- Mailcow requires a public domain with DNS configured (A, MX records).
- Setup SPF, DKIM, DMARC for deliverability.
- Use Let's Encrypt for TLS (or provide certificates).
- This snippet is only a hint; follow official Mailcow install script for production.


### Example DNS Records for pelitaelectricalraya.tk
Assuming domain: pelitaelectricalraya.tk
- A record: pelitaelectricalraya.tk -> 203.0.113.45
- A record: mail.pelitaelectricalraya.tk -> 203.0.113.45
- MX record: pelitaelectricalraya.tk -> mail.pelitaelectricalraya.tk (priority 10)
- TXT (SPF): pelitaelectricalraya.tk -> "v=spf1 mx ~all"
- DKIM: will be provided by Mailcow; add the selector TXT record as instructed by Mailcow setup
- DMARC: _dmarc.pelitaelectricalraya.tk -> "v=DMARC1; p=none; rua=mailto:postmaster@pelitaelectricalraya.tk"

### Basic Mailcow deployment steps (summary)
1. Acquire a VPS with a public static IP.
2. Register or delegate DNS for pelitaelectricalraya.tk to your DNS provider.
3. Set A and MX records as above.
4. Follow Mailcow official install: https://mailcow.email/docs/
5. Configure SSL (Let's Encrypt) during Mailcow setup or provide certs.
6. After running, verify SPF/DKIM/DMARC reports and test sending/receiving.
