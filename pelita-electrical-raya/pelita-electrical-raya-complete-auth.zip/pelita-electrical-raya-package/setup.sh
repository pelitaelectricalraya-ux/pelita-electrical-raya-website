#!/bin/bash
# One-line setup for Linux (requires sudo, docker & docker-compose)
set -e
ROOT=$(cd "$(dirname "$0")"; pwd)
echo "Adding hosts entry (127.0.0.1 pelitaelectricalraya.tk)"
if ! grep -q "pelitaelectricalraya.tk" /etc/hosts; then
  echo "127.0.0.1 pelitaelectricalraya.tk" | sudo tee -a /etc/hosts
fi
echo "Starting docker compose..."
docker compose up --build -d
echo "Done. Visit http://pelitaelectricalraya.tk"
